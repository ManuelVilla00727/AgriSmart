# AgriSmart · Arquitecturas cloud, fog e híbrida

Repositorio base del artículo **"Evaluación experimental de arquitecturas cloud-céntrica, fog on-premise e híbrida edge–fog–cloud para la delimitación de zonas de manejo agrícola mediante clustering con restricciones de tamaño: caso AgriSmart, Latacunga, Ecuador"**.

Proyecto de investigación formativa AgriSmart Latacunga · Universidad Técnica de Cotopaxi · GI-AISE.
Responsable: Ing. Manuel Villa.

## Idea central

Las tres arquitecturas ejecutan **el mismo servicio** (misma imagen Docker, misma API, mismo algoritmo y mismos datos). Lo único que cambia es **dónde se procesa y dónde se guardan los datos**. Eso es lo que mide el artículo.

| | A · Cloud-céntrica | B · Fog on-premise | C · Híbrida edge–fog–cloud |
|---|---|---|---|
| Dónde se calculan las zonas | AWS (EC2) | Servidor HP | Servidor HP |
| Base de datos | AWS | Servidor HP | Servidor HP + copia en AWS |
| Broker MQTT | AWS | Servidor HP | Servidor HP |
| Si se cae internet | El sistema no responde | Sigue funcionando | Sigue funcionando y sincroniza al volver |
| Despliegue | `deploy/cloud` | `deploy/fog` | `deploy/hybrid` + `deploy/cloud` |
| Grupo responsable | G3 | G4 | G5 + G4 |

Explicación completa con diagramas: [`docs/01-arquitecturas.md`](docs/01-arquitecturas.md).

## Estructura

```
service/        Servicio de zonas (FastAPI): k-means, k-means con restricciones de tamaño, MILP, métricas.
ingest/         Ingesta MQTT -> API (corre junto al broker).
sync/           Sincronizador fog -> nube con patrón outbox (solo híbrida).
db/             Esquema PostgreSQL/PostGIS común.
mosquitto/      Configuración del broker MQTT.
deploy/         Un docker-compose por arquitectura: cloud, fog, hybrid.
monitoring/     Prometheus, Grafana, node-exporter y cAdvisor (perfil "monitoreo").
edge/           Firmware de los nodos ESP32 y del gateway LoRa->MQTT, y simulador de nodos.
data/           Descarga de SoilGrids, NPK sintético, carga en PostGIS y solicitudes de prueba.
experiments/    Matriz de escenarios, pruebas de carga k6, inyección de fallos, resiliencia.
analysis/       Análisis estadístico y figuras para el artículo.
docs/           Guías para los estudiantes, contrato de la API y registros de decisiones (ADR).
```

## Arranque rápido en una computadora (sin hardware)

```bash
# 1. Servicio en local (Python 3.12)
cd service
pip install -r requirements-dev.txt
pytest -q                                   # 7 pruebas deben pasar
uvicorn app.main:app --reload               # documentación interactiva en http://localhost:8000/docs

# 2. Solicitud de prueba con datos sintéticos
cd ../data
python preparar_solicitudes.py --sinteticas --tamanos 300 --salida ../experiments/solicitudes
curl -X POST localhost:8000/v1/zonas -H "Content-Type: application/json" \
     -d @../experiments/solicitudes/solicitud_n300.json
```

Para desplegar cada arquitectura sigue el README de su carpeta en `deploy/`.

## Reglas del repositorio

1. Cada grupo trabaja en su rama (`g1-datos`, `g3-cloud`, ...) y une con *pull request* revisado por su líder.
2. **Nunca** se suben claves: van en `.env` (ya está en `.gitignore`). Copia `.env.example` y cámbialo.
3. Ningún grupo cambia `service/` sin aprobación del autor: el servicio debe ser idéntico en las tres arquitecturas.
4. Los resultados de experimentos no se editan a mano: se regeneran con los scripts.
5. Antes de la aprobación del anteproyecto (3 de diciembre de 2026) no se ejecutan experimentos definitivos.

## Estado de verificación de este material

| Componente | Verificado |
|---|---|
| Servicio de zonas y pruebas automáticas | Sí (7 pruebas pasan) |
| Ingesta MQTT, simulador y store-and-forward con corte de broker | Sí, en local |
| Experimento de resiliencia (`medir_resiliencia.py`) | Sí, en local |
| Análisis estadístico y figuras (con datos simulados) | Sí |
| Archivos docker-compose | Sintaxis validada (`docker compose config`); falta levantarlos en AWS y en el servidor HP |
| Sincronizador fog -> nube | Revisado, falta probar con PostgreSQL real (S11–S12) |
| Descarga de SoilGrids | Falta probar con acceso a internet (tarea de G1 en S1) |
| Firmware ESP32 y gateway | Falta compilar y probar con las placas (tarea de G5 en S1–S3) |

Material de partida: los grupos lo completan y lo prueban en sus semanas del cronograma.
