"""Análisis estadístico de los experimentos (grupo G7).

Lee resultados/rendimiento.csv y resultados/resiliencia.csv y produce:
  - tablas descriptivas por arquitectura (mediana, rango intercuartílico, media, desviación);
  - prueba de normalidad (Shapiro-Wilk) por grupo;
  - comparación de las tres arquitecturas en cada condición:
        Kruskal-Wallis (si no hay normalidad) o ANOVA de una vía, con tamaño de efecto;
        comparaciones por pares Mann-Whitney con corrección de Holm;
  - figuras en blanco y negro listas para el artículo.

Para practicar antes de tener datos reales:
  python analisis.py --simular
Con datos reales:
  python analisis.py --rendimiento ../experiments/resultados/rendimiento.csv \
                     --resiliencia ../experiments/resultados/resiliencia.csv
"""
from __future__ import annotations

import argparse
import itertools
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

ARQ = ["cloud", "fog", "hibrida"]
NOMBRES = {"cloud": "Cloud-céntrica", "fog": "Fog on-premise", "hibrida": "Híbrida"}
ALFA = 0.05


def simular() -> tuple[pd.DataFrame, pd.DataFrame]:
    """Datos con la misma estructura que los reales (solo para practicar el análisis)."""
    rng = np.random.default_rng(7)
    filas = []
    base_red = {"cloud": 120, "fog": 8, "hibrida": 10}
    for a, n, v, r in itertools.product(ARQ, [300, 1000, 2500], [1, 8, 32], range(1, 31)):
        algoritmo = {300: 60, 1000: 180, 2500: 1300}[n]
        saturacion = {"cloud": 1.0, "fog": 1.6, "hibrida": 1.5}[a] if v == 32 else 1.0
        p95 = (algoritmo * (1 + v / 10) * saturacion + base_red[a]) * rng.lognormal(0, 0.12)
        filas.append({"arquitectura": a, "n": n, "vus": v, "rep": r, "lat_p95_ms": p95,
                      "throughput_rps": v / (p95 / 1000) * rng.uniform(0.8, 1.0), "tasa_error": 0.0})
    resi = []
    for a, c, r in itertools.product(ARQ, [60, 300], range(1, 11)):
        perdida = {"cloud": 0.0, "fog": 0.0, "hibrida": 0.0}[a]
        rec = {"cloud": 25 + c * 0.05, "fog": 15, "hibrida": 30 + c * 0.1}[a] * rng.lognormal(0, 0.2)
        resi.append({"arquitectura": a, "corte_s": c, "rep": r, "tasa_perdida": perdida, "recuperacion_s": rec})
    return pd.DataFrame(filas), pd.DataFrame(resi)


def holm(pvals: list[float]) -> list[float]:
    orden = np.argsort(pvals)
    m = len(pvals)
    ajust = np.empty(m)
    acumulado = 0.0
    for rango, i in enumerate(orden):
        acumulado = max(acumulado, min(1.0, (m - rango) * pvals[i]))
        ajust[i] = acumulado
    return ajust.tolist()


def comparar(df: pd.DataFrame, metrica: str, condiciones: list[str]) -> pd.DataFrame:
    salida = []
    for clave, g in df.groupby(condiciones):
        grupos = [g.loc[g.arquitectura == a, metrica].dropna().values for a in ARQ]
        if min(len(x) for x in grupos) < 3:
            continue
        normal = all(stats.shapiro(x).pvalue > ALFA for x in grupos)
        if normal:
            est, p = stats.f_oneway(*grupos)
            prueba = "ANOVA"
            n_total = sum(len(x) for x in grupos)
            gran_media = np.concatenate(grupos).mean()
            ss_entre = sum(len(x) * (x.mean() - gran_media) ** 2 for x in grupos)
            ss_total = ((np.concatenate(grupos) - gran_media) ** 2).sum()
            efecto = ss_entre / ss_total if ss_total else np.nan          # eta cuadrado
        else:
            est, p = stats.kruskal(*grupos)
            prueba = "Kruskal-Wallis"
            n_total = sum(len(x) for x in grupos)
            efecto = (est - len(grupos) + 1) / (n_total - len(grupos))      # épsilon cuadrado
        pares = list(itertools.combinations(range(3), 2))
        p_pares = [stats.mannwhitneyu(grupos[i], grupos[j]).pvalue for i, j in pares]
        p_holm = holm(p_pares)
        fila = dict(zip(condiciones, clave if isinstance(clave, tuple) else (clave,)))
        fila.update({"metrica": metrica, "prueba": prueba, "estadistico": round(est, 3), "p": p,
                     "efecto": round(efecto, 3), **{f"mediana_{a}": round(np.median(x), 2) for a, x in zip(ARQ, grupos)}})
        for (i, j), ph in zip(pares, p_holm):
            fila[f"p_holm_{ARQ[i]}_vs_{ARQ[j]}"] = ph
        salida.append(fila)
    return pd.DataFrame(salida)


def figuras(rend: pd.DataFrame, resi: pd.DataFrame, carpeta: Path) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9})
    tramas = ["", "///", "..."]

    fig, ejes = plt.subplots(1, 3, figsize=(7.2, 2.6), sharey=False)
    for eje, n in zip(ejes, sorted(rend.n.unique())):
        sub = rend[rend.n == n]
        pos = 0
        for v in sorted(sub.vus.unique()):
            for k, a in enumerate(ARQ):
                datos = sub[(sub.vus == v) & (sub.arquitectura == a)].lat_p95_ms
                caja = eje.boxplot(datos, positions=[pos], widths=0.7, patch_artist=True, showfliers=False,
                                   medianprops={"color": "black"})
                caja["boxes"][0].set(facecolor="white", hatch=tramas[k])
                pos += 1
            pos += 1
        eje.set_xticks([1 + i * 4 for i in range(len(sub.vus.unique()))],
                       [str(v) for v in sorted(sub.vus.unique())])
        eje.set_xlabel("Usuarios concurrentes")
        eje.set_title(f"{n} celdas")
        eje.set_yscale("log")
    ejes[0].set_ylabel("Latencia p95 (ms, escala log)")
    from matplotlib.patches import Patch
    fig.legend([Patch(facecolor="white", edgecolor="black", hatch=t) for t in tramas],
               [NOMBRES[a] for a in ARQ], loc="lower center", ncol=3, frameon=False)
    fig.tight_layout(rect=(0, 0.1, 1, 1))
    fig.savefig(carpeta / "fig_latencia_p95.png", dpi=300)

    fig, eje = plt.subplots(figsize=(3.5, 2.6))
    pos = 0
    for c in sorted(resi.corte_s.unique()):
        for k, a in enumerate(ARQ):
            datos = resi[(resi.corte_s == c) & (resi.arquitectura == a)].recuperacion_s.dropna()
            caja = eje.boxplot(datos, positions=[pos], widths=0.7, patch_artist=True, showfliers=False,
                                   medianprops={"color": "black"})
            caja["boxes"][0].set(facecolor="white", hatch=tramas[k])
            pos += 1
        pos += 1
    eje.set_xticks([1 + i * 4 for i in range(len(resi.corte_s.unique()))],
                   [f"{c} s" for c in sorted(resi.corte_s.unique())])
    eje.set_xlabel("Duración del corte de red")
    eje.set_ylabel("Tiempo de recuperación (s)")
    fig.tight_layout()
    fig.savefig(carpeta / "fig_recuperacion.png", dpi=300)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--simular", action="store_true")
    ap.add_argument("--rendimiento")
    ap.add_argument("--resiliencia")
    ap.add_argument("--salida", default="salida")
    a = ap.parse_args()
    if a.simular:
        rend, resi = simular()
    else:
        rend, resi = pd.read_csv(a.rendimiento), pd.read_csv(a.resiliencia)
    carpeta = Path(a.salida)
    carpeta.mkdir(exist_ok=True)

    desc = rend.groupby(["n", "vus", "arquitectura"]).lat_p95_ms.describe(percentiles=[0.25, 0.5, 0.75]).round(2)
    desc.to_csv(carpeta / "descriptivos_latencia.csv")
    tabla = pd.concat([comparar(rend, "lat_p95_ms", ["n", "vus"]), comparar(rend, "throughput_rps", ["n", "vus"]),
                       comparar(resi, "recuperacion_s", ["corte_s"]), comparar(resi, "tasa_perdida", ["corte_s"])],
                      ignore_index=True)
    tabla.to_csv(carpeta / "pruebas_estadisticas.csv", index=False)
    figuras(rend, resi, carpeta)
    sig = tabla[tabla.p < ALFA]
    print(f"{len(tabla)} comparaciones; {len(sig)} con diferencias significativas (alfa = {ALFA}).")
    print(f"Resultados en {carpeta}/: descriptivos_latencia.csv, pruebas_estadisticas.csv, fig_*.png")
    if a.simular:
        print("AVISO: datos SIMULADOS. No usar estos números en el artículo.")


if __name__ == "__main__":
    main()
