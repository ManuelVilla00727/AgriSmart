-- Esquema común de AgriSmart. Se ejecuta automáticamente la primera vez que arranca PostGIS.
CREATE EXTENSION IF NOT EXISTS postgis;

-- Celdas de suelo (SoilGrids + NPK sintético). Las carga el grupo G1 con data/cargar_celdas.py
CREATE TABLE IF NOT EXISTS celdas (
    id               TEXT PRIMARY KEY,
    geom             GEOMETRY(Point, 4326) NOT NULL,
    ph               REAL,
    nitrogeno        REAL,
    carbono_organico REAL,
    arcilla          REAL,
    arena            REAL,
    limo             REAL,
    fosforo          REAL,
    potasio          REAL,
    fuente           TEXT DEFAULT 'soilgrids'
);
CREATE INDEX IF NOT EXISTS celdas_geom_idx ON celdas USING GIST (geom);

-- Lecturas de los nodos ESP32. (nodo_id, secuencia) evita duplicados al reenviar tras un corte.
CREATE TABLE IF NOT EXISTS lecturas (
    nodo_id           TEXT        NOT NULL,
    secuencia         BIGINT      NOT NULL,
    medido_en         TIMESTAMPTZ NOT NULL,
    recibido_en       TIMESTAMPTZ NOT NULL DEFAULT now(),
    humedad_suelo     REAL,
    temperatura_suelo REAL,
    temperatura_aire  REAL,
    humedad_aire      REAL,
    bateria_v         REAL,
    rssi              REAL,
    origen            TEXT,
    sincronizado      BOOLEAN     NOT NULL DEFAULT false,  -- solo lo usa la arquitectura híbrida
    PRIMARY KEY (nodo_id, secuencia)
);
CREATE INDEX IF NOT EXISTS lecturas_pendientes_idx ON lecturas (sincronizado) WHERE sincronizado = false;
CREATE INDEX IF NOT EXISTS lecturas_medido_idx ON lecturas (medido_en DESC);

-- Registro de cada cálculo de zonas: insumo directo para el análisis del artículo.
CREATE TABLE IF NOT EXISTS trabajos (
    trabajo_id           UUID PRIMARY KEY,
    creado_en            TIMESTAMPTZ NOT NULL DEFAULT now(),
    metodo               TEXT NOT NULL,
    k                    INT NOT NULL,
    n_celdas             INT NOT NULL,
    tiempo_algoritmo_ms  DOUBLE PRECISION,
    tiempo_total_ms      DOUBLE PRECISION,
    metricas             JSONB,
    arquitectura         TEXT,
    nodo                 TEXT,
    etiqueta_experimento TEXT
);
