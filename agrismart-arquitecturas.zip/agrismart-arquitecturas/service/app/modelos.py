"""Contrato de la API (el mismo en las tres arquitecturas)."""
from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field, model_validator

VARIABLES_PERMITIDAS = {"ph", "nitrogeno", "carbono_organico", "arcilla", "arena", "limo",
                        "fosforo", "potasio", "humedad", "temperatura"}


class Celda(BaseModel):
    id: str = Field(..., description="Identificador único de la celda (por ejemplo, fila_columna de SoilGrids)")
    lat: float = Field(..., ge=-90, le=90)
    lon: float = Field(..., ge=-180, le=180)
    ph: float | None = Field(None, description="pH en agua (unidades de pH, ya convertido)")
    nitrogeno: float | None = Field(None, description="Nitrógeno total, g/kg")
    carbono_organico: float | None = Field(None, description="Carbono orgánico, g/kg")
    arcilla: float | None = Field(None, description="% de arcilla")
    arena: float | None = Field(None, description="% de arena")
    limo: float | None = Field(None, description="% de limo")
    fosforo: float | None = Field(None, description="Fósforo, mg/kg (sintético o medido)")
    potasio: float | None = Field(None, description="Potasio, cmol/kg (sintético o medido)")
    humedad: float | None = None
    temperatura: float | None = None


class SolicitudZonas(BaseModel):
    celdas: list[Celda] = Field(..., min_length=2)
    k: int = Field(..., ge=2, le=50, description="Número de zonas de manejo")
    metodo: Literal["kmeans", "kmeans_tamano", "milp"] = "kmeans_tamano"
    tamano_min: int | None = Field(None, ge=0, description="Celdas mínimas por zona")
    tamano_max: int | None = Field(None, ge=1, description="Celdas máximas por zona")
    variables: list[str] = Field(default_factory=lambda: ["ph", "nitrogeno", "carbono_organico", "arcilla", "arena"])
    peso_espacial: float = Field(0.5, ge=0, le=5, description="Peso de las coordenadas: 0 ignora la cercanía")
    semilla: int = 42
    etiqueta_experimento: str | None = Field(None, description="Escenario del experimento, para el registro")

    @model_validator(mode="after")
    def _validar(self):
        malas = set(self.variables) - VARIABLES_PERMITIDAS
        if malas:
            raise ValueError(f"Variables no permitidas: {sorted(malas)}")
        if self.metodo != "kmeans" and (self.tamano_min is None or self.tamano_max is None):
            raise ValueError("kmeans_tamano y milp requieren tamano_min y tamano_max.")
        return self


class Asignacion(BaseModel):
    id: str
    zona: int


class RespuestaZonas(BaseModel):
    trabajo_id: str
    metodo: str
    k: int
    asignaciones: list[Asignacion]
    metricas: dict
    estado_solver: str
    iteraciones: int
    tiempo_algoritmo_ms: float
    tiempo_total_ms: float
    arquitectura: str
    nodo: str


class Lectura(BaseModel):
    nodo_id: str
    secuencia: int = Field(..., ge=0, description="Contador del nodo; permite detectar pérdidas y duplicados")
    medido_en: datetime
    humedad_suelo: float | None = None
    temperatura_suelo: float | None = None
    temperatura_aire: float | None = None
    humedad_aire: float | None = None
    bateria_v: float | None = None
    rssi: float | None = None


class LoteLecturas(BaseModel):
    origen: str = Field("desconocido", description="gateway, sincronizador o simulador")
    lecturas: list[Lectura] = Field(..., min_length=1, max_length=5000)
