"""Persistencia. Usa PostgreSQL/PostGIS si existe DATABASE_URL; si no, memoria (solo pruebas)."""
from __future__ import annotations

import json
import os
import threading

DATABASE_URL = os.getenv("DATABASE_URL")


class AlmacenMemoria:
    def __init__(self):
        self._lock = threading.Lock()
        self.lecturas: dict[tuple[str, int], dict] = {}
        self.trabajos: list[dict] = []

    def guardar_lecturas(self, lecturas: list[dict], origen: str) -> tuple[int, int]:
        nuevas = 0
        with self._lock:
            for l in lecturas:
                clave = (l["nodo_id"], l["secuencia"])
                if clave not in self.lecturas:
                    self.lecturas[clave] = {**l, "origen": origen}
                    nuevas += 1
        return nuevas, len(lecturas) - nuevas

    def ultimas_lecturas(self, limite: int) -> list[dict]:
        with self._lock:
            return sorted(self.lecturas.values(), key=lambda l: str(l["medido_en"]), reverse=True)[:limite]

    def guardar_trabajo(self, t: dict) -> None:
        with self._lock:
            self.trabajos.append(t)

    def resumen(self) -> dict:
        with self._lock:
            nodos: dict[str, list[int]] = {}
            for (n, s) in self.lecturas:
                nodos.setdefault(n, []).append(s)
        return {"total": sum(len(v) for v in nodos.values()),
                "nodos": {n: {"recibidas": len(v), "max_secuencia": max(v)} for n, v in sorted(nodos.items())}}

    def ping(self) -> bool:
        return True


class AlmacenPostgres:
    def __init__(self, url: str):
        from psycopg_pool import ConnectionPool  # se instala con psycopg[pool]
        self.pool = ConnectionPool(url, min_size=1, max_size=10, open=True)

    def guardar_lecturas(self, lecturas: list[dict], origen: str) -> tuple[int, int]:
        sql = """INSERT INTO lecturas (nodo_id, secuencia, medido_en, humedad_suelo, temperatura_suelo,
                 temperatura_aire, humedad_aire, bateria_v, rssi, origen)
                 VALUES (%(nodo_id)s, %(secuencia)s, %(medido_en)s, %(humedad_suelo)s, %(temperatura_suelo)s,
                 %(temperatura_aire)s, %(humedad_aire)s, %(bateria_v)s, %(rssi)s, %(origen)s)
                 ON CONFLICT (nodo_id, secuencia) DO NOTHING"""
        nuevas = 0
        with self.pool.connection() as con, con.cursor() as cur:
            for l in lecturas:
                cur.execute(sql, {**l, "origen": origen})
                nuevas += cur.rowcount
        return nuevas, len(lecturas) - nuevas

    def ultimas_lecturas(self, limite: int) -> list[dict]:
        with self.pool.connection() as con, con.cursor() as cur:
            cur.execute("""SELECT nodo_id, secuencia, medido_en, humedad_suelo, temperatura_suelo,
                           temperatura_aire, humedad_aire, bateria_v, rssi, origen
                           FROM lecturas ORDER BY medido_en DESC LIMIT %s""", (limite,))
            cols = [c.name for c in cur.description]
            return [dict(zip(cols, r)) for r in cur.fetchall()]

    def guardar_trabajo(self, t: dict) -> None:
        with self.pool.connection() as con, con.cursor() as cur:
            cur.execute("""INSERT INTO trabajos (trabajo_id, metodo, k, n_celdas, tiempo_algoritmo_ms,
                           tiempo_total_ms, metricas, arquitectura, nodo, etiqueta_experimento)
                           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                        (t["trabajo_id"], t["metodo"], t["k"], t["n_celdas"], t["tiempo_algoritmo_ms"],
                         t["tiempo_total_ms"], json.dumps(t["metricas"]), t["arquitectura"], t["nodo"],
                         t.get("etiqueta_experimento")))

    def resumen(self) -> dict:
        with self.pool.connection() as con, con.cursor() as cur:
            cur.execute("SELECT nodo_id, count(*), max(secuencia) FROM lecturas GROUP BY nodo_id ORDER BY nodo_id")
            filas = cur.fetchall()
        return {"total": sum(f[1] for f in filas),
                "nodos": {f[0]: {"recibidas": f[1], "max_secuencia": f[2]} for f in filas}}

    def ping(self) -> bool:
        with self.pool.connection() as con, con.cursor() as cur:
            cur.execute("SELECT 1")
            return cur.fetchone()[0] == 1


almacen = AlmacenPostgres(DATABASE_URL) if DATABASE_URL else AlmacenMemoria()
