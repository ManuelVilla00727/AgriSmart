"""Algoritmos de delimitación de zonas de manejo.

Tres métodos, todos con la misma entrada (matriz de variables ya normalizada)
y la misma salida (etiqueta de zona por celda):

- kmeans          : línea base sin restricciones de tamaño (scikit-learn).
- kmeans_tamano   : k-means con restricciones de tamaño mínimo y máximo por zona.
                    En cada iteración la asignación se resuelve de forma exacta como
                    un problema de asignación (algoritmo húngaro de SciPy), siguiendo
                    la idea de Bradley, Bennett y Demiriz (2000).
- milp            : p-mediana capacitada resuelta con programación lineal entera
                    mixta (PuLP + CBC). Es el método exacto; solo para tamaños pequeños.
"""
from __future__ import annotations

import time
from dataclasses import dataclass

import numpy as np
from scipy.optimize import linear_sum_assignment
from sklearn.cluster import KMeans

# Límites de seguridad: protegen al servidor de solicitudes que no terminarían.
MAX_CELDAS_KMEANS_TAMANO = 3000
MAX_CELDAS_MILP = 400


@dataclass
class ResultadoClustering:
    etiquetas: np.ndarray
    centros: np.ndarray
    iteraciones: int
    estado: str
    tiempo_algoritmo_ms: float


def _validar_tamanos(n: int, k: int, tmin: int, tmax: int) -> None:
    if k < 2:
        raise ValueError("Se necesitan al menos 2 zonas.")
    if k > n:
        raise ValueError("Hay más zonas que celdas.")
    if tmin < 0 or tmax < 1 or tmin > tmax:
        raise ValueError("Tamaños inválidos: se requiere 0 <= tamano_min <= tamano_max.")
    if k * tmin > n:
        raise ValueError(f"Imposible: {k} zonas x {tmin} celdas mínimas = {k * tmin} > {n} celdas.")
    if k * tmax < n:
        raise ValueError(f"Imposible: {k} zonas x {tmax} celdas máximas = {k * tmax} < {n} celdas.")


def kmeans(X: np.ndarray, k: int, semilla: int = 42) -> ResultadoClustering:
    t0 = time.perf_counter()
    modelo = KMeans(n_clusters=k, n_init=10, random_state=semilla).fit(X)
    return ResultadoClustering(
        etiquetas=modelo.labels_,
        centros=modelo.cluster_centers_,
        iteraciones=int(modelo.n_iter_),
        estado="optimo_local",
        tiempo_algoritmo_ms=(time.perf_counter() - t0) * 1000,
    )


def _asignacion_con_tamanos(X: np.ndarray, centros: np.ndarray, tmin: int, tmax: int) -> np.ndarray:
    """Asigna cada celda a una zona respetando tamaños mínimos y máximos.

    Cada zona se representa con `tmax` casillas: las primeras `tmin` son obligatorias
    (costo con un gran descuento, para que se llenen siempre) y el resto opcionales.
    El algoritmo húngaro asigna cada celda a una casilla con costo mínimo.
    """
    n, k = X.shape[0], centros.shape[0]
    d = ((X[:, None, :] - centros[None, :, :]) ** 2).sum(axis=2)  # n x k
    grande = d.max() * n + 1.0
    columnas = []
    duenos = []
    for j in range(k):
        for s in range(tmax):
            columnas.append(d[:, j] - (grande if s < tmin else 0.0))
            duenos.append(j)
    costo = np.stack(columnas, axis=1)  # n x (k*tmax)
    filas, cols = linear_sum_assignment(costo)
    etiquetas = np.empty(n, dtype=int)
    etiquetas[filas] = np.asarray(duenos)[cols]
    return etiquetas


def kmeans_tamano(X: np.ndarray, k: int, tmin: int, tmax: int, semilla: int = 42,
                  max_iter: int = 30) -> ResultadoClustering:
    n = X.shape[0]
    _validar_tamanos(n, k, tmin, tmax)
    if n > MAX_CELDAS_KMEANS_TAMANO:
        raise ValueError(f"kmeans_tamano admite hasta {MAX_CELDAS_KMEANS_TAMANO} celdas por solicitud.")
    t0 = time.perf_counter()
    centros = KMeans(n_clusters=k, n_init=5, random_state=semilla).fit(X).cluster_centers_
    etiquetas = None
    it = 0
    for it in range(1, max_iter + 1):
        nuevas = _asignacion_con_tamanos(X, centros, tmin, tmax)
        if etiquetas is not None and np.array_equal(nuevas, etiquetas):
            break
        etiquetas = nuevas
        centros = np.vstack([X[etiquetas == j].mean(axis=0) for j in range(k)])
    return ResultadoClustering(etiquetas, centros, it, "convergio" if it < max_iter else "max_iter",
                               (time.perf_counter() - t0) * 1000)


def milp(X: np.ndarray, k: int, tmin: int, tmax: int, limite_s: int = 60) -> ResultadoClustering:
    """p-mediana capacitada.

    min  sum_ij d_ij x_ij
    s.a. sum_j x_ij = 1                      (cada celda en una zona)
         x_ij <= y_j                         (solo a medianas abiertas)
         sum_j y_j = k                       (exactamente k zonas)
         tmin y_j <= sum_i x_ij <= tmax y_j  (tamaño de cada zona)
         x_ij, y_j binarias
    """
    import pulp  # import local: solo se carga si se usa el método

    n = X.shape[0]
    _validar_tamanos(n, k, tmin, tmax)
    if n > MAX_CELDAS_MILP:
        raise ValueError(f"milp admite hasta {MAX_CELDAS_MILP} celdas por solicitud.")
    t0 = time.perf_counter()
    d = np.sqrt(((X[:, None, :] - X[None, :, :]) ** 2).sum(axis=2))
    prob = pulp.LpProblem("p_mediana_capacitada", pulp.LpMinimize)
    y = [pulp.LpVariable(f"y_{j}", cat="Binary") for j in range(n)]
    x = [[pulp.LpVariable(f"x_{i}_{j}", cat="Binary") for j in range(n)] for i in range(n)]
    prob += pulp.lpSum(float(d[i, j]) * x[i][j] for i in range(n) for j in range(n))
    for i in range(n):
        prob += pulp.lpSum(x[i]) == 1
        for j in range(n):
            prob += x[i][j] <= y[j]
    prob += pulp.lpSum(y) == k
    for j in range(n):
        tam = pulp.lpSum(x[i][j] for i in range(n))
        prob += tam >= tmin * y[j]
        prob += tam <= tmax * y[j]
    prob.solve(pulp.PULP_CBC_CMD(msg=False, timeLimit=limite_s))
    estado = pulp.LpStatus[prob.status]
    medianas = [j for j in range(n) if (y[j].value() or 0) > 0.5]
    if len(medianas) != k:
        raise RuntimeError(f"El solver no encontró solución factible (estado: {estado}).")
    indice = {m: z for z, m in enumerate(medianas)}
    etiquetas = np.empty(n, dtype=int)
    for i in range(n):
        etiquetas[i] = indice[max(medianas, key=lambda j: x[i][j].value() or 0)]
    centros = X[medianas]
    return ResultadoClustering(etiquetas, centros, 1, estado.lower(), (time.perf_counter() - t0) * 1000)
