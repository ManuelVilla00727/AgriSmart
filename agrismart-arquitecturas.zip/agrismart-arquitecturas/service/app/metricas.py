"""Métricas de calidad de las zonas de manejo.

Deben salir iguales en las tres arquitecturas: si no, la comparación no es justa.
"""
from __future__ import annotations

import numpy as np
from sklearn.metrics import silhouette_score


def calcular(X: np.ndarray, etiquetas: np.ndarray, k: int, tmin: int | None, tmax: int | None) -> dict:
    tamanos = np.bincount(etiquetas, minlength=k)
    var_total = float(((X - X.mean(axis=0)) ** 2).sum())
    var_intra = float(sum(((X[etiquetas == j] - X[etiquetas == j].mean(axis=0)) ** 2).sum()
                          for j in range(k) if tamanos[j] > 0))
    try:
        silueta = float(silhouette_score(X, etiquetas)) if 1 < len(set(etiquetas)) < len(X) else None
    except ValueError:
        silueta = None
    if tmin is not None and tmax is not None:
        cumplen = int(((tamanos >= tmin) & (tamanos <= tmax)).sum())
        cumplimiento = cumplen / k
    else:
        cumplimiento = None
    return {
        "tamanos": tamanos.tolist(),
        "varianza_intra": round(var_intra, 6),
        # Proporción de la varianza total que queda dentro de las zonas (menor es mejor).
        "varianza_intra_relativa": round(var_intra / var_total, 6) if var_total > 0 else None,
        "silueta": round(silueta, 6) if silueta is not None else None,
        "cumplimiento_tamanos": cumplimiento,
    }
