"""Servicio de zonas de manejo AgriSmart.

Es EL MISMO contenedor en las tres arquitecturas. Solo cambian las variables de entorno:
  ARQUITECTURA = cloud | fog | hibrida
  DATABASE_URL = postgresql://usuario:clave@host:5432/agrismart   (opcional)
"""
from __future__ import annotations

import os
import socket
import time
import uuid

import numpy as np
from fastapi import FastAPI, HTTPException, Query, Response
from prometheus_client import CONTENT_TYPE_LATEST, Counter, Histogram, generate_latest

from . import clustering, metricas
from .almacen import almacen
from .modelos import LoteLecturas, RespuestaZonas, SolicitudZonas

ARQUITECTURA = os.getenv("ARQUITECTURA", "local")
NODO = socket.gethostname()
VERSION = "1.0.0"

app = FastAPI(
    title="AgriSmart · Servicio de zonas de manejo",
    version=VERSION,
    description="Delimitación de zonas de manejo agrícola con clustering con restricciones de tamaño. "
                "Contrato común para las arquitecturas cloud-céntrica, fog on-premise e híbrida.",
)

SOLICITUDES = Counter("agrismart_solicitudes_total", "Solicitudes de zonas", ["metodo", "resultado"])
DURACION = Histogram("agrismart_zonas_segundos", "Tiempo de cálculo de zonas", ["metodo"],
                     buckets=(0.01, 0.05, 0.1, 0.25, 0.5, 1, 2, 5, 10, 30, 60, 120))
LECTURAS = Counter("agrismart_lecturas_total", "Lecturas recibidas", ["origen", "tipo"])


def _matriz(sol: SolicitudZonas) -> np.ndarray:
    """Construye la matriz de variables estandarizadas (media 0, desviación 1).

    Las coordenadas se agregan con `peso_espacial` para que las zonas tiendan a ser contiguas.
    """
    columnas = []
    for v in sol.variables:
        valores = [getattr(c, v) for c in sol.celdas]
        if any(x is None for x in valores):
            raise HTTPException(422, f"La variable '{v}' falta en al menos una celda.")
        columnas.append(valores)
    X = np.asarray(columnas, dtype=float).T
    if sol.peso_espacial > 0:
        coords = np.array([[c.lat, c.lon] for c in sol.celdas], dtype=float)
        X = np.hstack([X, coords])
    std = X.std(axis=0)
    std[std == 0] = 1.0
    X = (X - X.mean(axis=0)) / std
    if sol.peso_espacial > 0:
        X[:, -2:] *= sol.peso_espacial
    return X


@app.get("/health", tags=["operación"])
def health():
    try:
        bd = almacen.ping()
    except Exception:  # la base de datos caída no debe tumbar el health
        bd = False
    return {"estado": "ok", "arquitectura": ARQUITECTURA, "nodo": NODO, "version": VERSION, "base_datos": bd}


@app.get("/metrics", include_in_schema=False)
def metrics():
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)


@app.post("/v1/zonas", response_model=RespuestaZonas, tags=["zonas"])
def calcular_zonas(sol: SolicitudZonas):
    t0 = time.perf_counter()
    X = _matriz(sol)
    try:
        with DURACION.labels(sol.metodo).time():
            if sol.metodo == "kmeans":
                r = clustering.kmeans(X, sol.k, sol.semilla)
            elif sol.metodo == "kmeans_tamano":
                r = clustering.kmeans_tamano(X, sol.k, sol.tamano_min, sol.tamano_max, sol.semilla)
            else:
                r = clustering.milp(X, sol.k, sol.tamano_min, sol.tamano_max)
    except ValueError as e:
        SOLICITUDES.labels(sol.metodo, "invalida").inc()
        raise HTTPException(422, str(e)) from e
    except RuntimeError as e:
        SOLICITUDES.labels(sol.metodo, "sin_solucion").inc()
        raise HTTPException(409, str(e)) from e
    m = metricas.calcular(X, r.etiquetas, sol.k, sol.tamano_min, sol.tamano_max)
    total_ms = (time.perf_counter() - t0) * 1000
    respuesta = RespuestaZonas(
        trabajo_id=str(uuid.uuid4()), metodo=sol.metodo, k=sol.k,
        asignaciones=[{"id": c.id, "zona": int(z)} for c, z in zip(sol.celdas, r.etiquetas)],
        metricas=m, estado_solver=r.estado, iteraciones=r.iteraciones,
        tiempo_algoritmo_ms=round(r.tiempo_algoritmo_ms, 3), tiempo_total_ms=round(total_ms, 3),
        arquitectura=ARQUITECTURA, nodo=NODO,
    )
    try:
        almacen.guardar_trabajo({**respuesta.model_dump(exclude={"asignaciones"}), "n_celdas": len(sol.celdas),
                                 "etiqueta_experimento": sol.etiqueta_experimento})
    except Exception:
        pass  # el registro del trabajo no debe hacer fallar el cálculo; queda en los logs de Prometheus
    SOLICITUDES.labels(sol.metodo, "ok").inc()
    return respuesta


@app.post("/v1/lecturas", tags=["lecturas"])
def recibir_lecturas(lote: LoteLecturas):
    """Recibe lecturas de los nodos. Es idempotente: (nodo_id, secuencia) repetidos se ignoran.

    Así el sincronizador puede reenviar sin miedo a duplicar datos tras un corte de red.
    """
    nuevas, duplicadas = almacen.guardar_lecturas([l.model_dump() for l in lote.lecturas], lote.origen)
    LECTURAS.labels(lote.origen, "nueva").inc(nuevas)
    LECTURAS.labels(lote.origen, "duplicada").inc(duplicadas)
    return {"recibidas": len(lote.lecturas), "nuevas": nuevas, "duplicadas": duplicadas}


@app.get("/v1/lecturas/ultimas", tags=["lecturas"])
def ultimas(limite: int = Query(50, ge=1, le=1000)):
    return almacen.ultimas_lecturas(limite)


@app.get("/v1/lecturas/resumen", tags=["lecturas"])
def resumen():
    """Lecturas recibidas por nodo. Si max_secuencia > recibidas, faltan lecturas (pérdida)."""
    return almacen.resumen()
