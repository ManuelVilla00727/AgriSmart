import numpy as np
from fastapi.testclient import TestClient

from app import clustering
from app.main import app

cliente = TestClient(app)


def _celdas(n, semilla=0):
    rng = np.random.default_rng(semilla)
    return [{"id": f"c{i}", "lat": -0.93 + rng.normal(0, 0.01), "lon": -78.6 + rng.normal(0, 0.01),
             "ph": float(rng.normal(6.2, 0.4)), "nitrogeno": float(rng.normal(2.0, 0.5)),
             "carbono_organico": float(rng.normal(25, 6)), "arcilla": float(rng.normal(18, 4)),
             "arena": float(rng.normal(45, 8))} for i in range(n)]


def test_health():
    r = cliente.get("/health")
    assert r.status_code == 200 and r.json()["estado"] == "ok"


def test_kmeans_tamano_respeta_tamanos():
    r = cliente.post("/v1/zonas", json={"celdas": _celdas(120), "k": 4, "metodo": "kmeans_tamano",
                                        "tamano_min": 25, "tamano_max": 35})
    assert r.status_code == 200, r.text
    m = r.json()["metricas"]
    assert all(25 <= t <= 35 for t in m["tamanos"])
    assert m["cumplimiento_tamanos"] == 1.0


def test_kmeans_base():
    r = cliente.post("/v1/zonas", json={"celdas": _celdas(80), "k": 3, "metodo": "kmeans"})
    assert r.status_code == 200
    assert len(r.json()["asignaciones"]) == 80


def test_milp_pequeno():
    r = cliente.post("/v1/zonas", json={"celdas": _celdas(30), "k": 3, "metodo": "milp",
                                        "tamano_min": 8, "tamano_max": 12})
    assert r.status_code == 200, r.text
    assert all(8 <= t <= 12 for t in r.json()["metricas"]["tamanos"])


def test_tamanos_imposibles():
    r = cliente.post("/v1/zonas", json={"celdas": _celdas(20), "k": 4, "metodo": "kmeans_tamano",
                                        "tamano_min": 6, "tamano_max": 8})
    assert r.status_code == 422


def test_lecturas_idempotentes():
    lote = {"origen": "prueba", "lecturas": [{"nodo_id": "n1", "secuencia": 1, "medido_en": "2026-11-09T10:00:00Z",
                                              "humedad_suelo": 31.5}]}
    a = cliente.post("/v1/lecturas", json=lote).json()
    b = cliente.post("/v1/lecturas", json=lote).json()
    assert a["nuevas"] == 1 and b["duplicadas"] == 1
    assert cliente.get("/v1/lecturas/resumen").json()["nodos"]["n1"]["recibidas"] == 1


def test_misma_semilla_mismo_resultado():
    X = np.random.default_rng(3).normal(size=(60, 4))
    a = clustering.kmeans_tamano(X, 3, 18, 22, semilla=7).etiquetas
    b = clustering.kmeans_tamano(X, 3, 18, 22, semilla=7).etiquetas
    assert np.array_equal(a, b)
