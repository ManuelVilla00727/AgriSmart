# A · Cloud-céntrica (grupo G3)

Todo el sistema corre en una instancia EC2 de AWS: base de datos, servicio de zonas, broker MQTT e ingesta.

## 1. Elegir la instancia (S3–S5)
- **Evita las instancias burstable (t2, t3, t4g)** para los experimentos: usan créditos de CPU y su rendimiento cambia con el tiempo, lo que ensucia las mediciones. Si por presupuesto usas una t3, actívala en modo *unlimited* y decláralo en el artículo.
- Opción sugerida: una instancia de propósito general con 2 vCPU y 8 GB (familia m6i o m7i, tamaño *large*). Revisa el precio en la calculadora de AWS antes de crearla.
- Los límites del servicio (`API_CPUS=2`, `API_MEMORIA=4g`) deben ser **iguales** a los del fog.
- Anota la región elegida (por ejemplo `us-east-1`) y justifícala en un ADR: la distancia a la región influye en la latencia.
- Sistema operativo: Ubuntu Server 24.04 LTS, disco de 30 GB.

## 2. Grupo de seguridad (firewall de AWS)
| Puerto | Para qué | Origen permitido |
|---|---|---|
| 22 | SSH | Solo la IP pública de la universidad |
| 8000 | API | IP de la universidad (generador de carga y sincronizador del fog) |
| 1883 | MQTT | IP desde la que sale el gateway |
| 3000, 9090 | Grafana y Prometheus | Solo la IP de la universidad |

Nunca abras estos puertos a `0.0.0.0/0`.

## 3. Instalación
```bash
# En la EC2
sudo apt update && sudo apt install -y docker.io docker-compose-v2 git
sudo usermod -aG docker $USER && newgrp docker
git clone <URL_DEL_REPOSITORIO> agrismart && cd agrismart

# Usuario del broker MQTT (guárdalo también en .env)
docker run --rm -v "$PWD/mosquitto:/mosquitto/config" eclipse-mosquitto:2 \
  mosquitto_passwd -b -c /mosquitto/config/passwd agrismart CLAVE_SEGURA

cd deploy/cloud
cp .env.example .env && nano .env        # cambia todas las claves
docker compose --profile broker --profile monitoreo up -d --build
curl localhost:8000/health               # debe decir "arquitectura": "cloud"
```

## 4. Uso como nube de la arquitectura híbrida
Para la híbrida, la nube solo recibe la copia de datos del sincronizador. Levántala **sin** el perfil `broker`:
```bash
docker compose --profile monitoreo up -d --build
```

## 5. Costos
- Crea una **alerta de presupuesto de 50 USD** en AWS Billing antes de empezar.
- Apaga la instancia (`Stop`) cuando no haya pruebas. Al terminar el artículo, elimina instancia, volúmenes y snapshots.
- Guarda la factura mensual: es el dato de costo real del artículo.
