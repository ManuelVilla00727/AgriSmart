# B · Fog on-premise (grupo G4)

Todo el sistema corre en el servidor HP de la universidad. No se usa la nube.

## 1. Preparar el servidor (S1–S2)
```bash
# Ubuntu Server 24.04 LTS ya instalado
sudo apt update && sudo apt full-upgrade -y
sudo apt install -y docker.io docker-compose-v2 git ufw
sudo usermod -aG docker $USER && newgrp docker

# SSH solo con llaves: copia tu llave pública y luego en /etc/ssh/sshd_config
#   PasswordAuthentication no
#   PermitRootLogin no
sudo systemctl restart ssh

# Firewall: solo lo necesario desde la red del laboratorio (ajusta la subred)
sudo ufw default deny incoming
sudo ufw allow from 192.168.1.0/24 to any port 22,8000,1883,3000,9090 proto tcp
sudo ufw enable
```
Anota en el inventario: modelo del servidor, CPU (núcleos), RAM y disco. Son datos del artículo.

## 2. Levantar la arquitectura
```bash
git clone <URL_DEL_REPOSITORIO> /opt/agrismart && cd /opt/agrismart
docker run --rm -v "$PWD/mosquitto:/mosquitto/config" eclipse-mosquitto:2 \
  mosquitto_passwd -b -c /mosquitto/config/passwd agrismart CLAVE_SEGURA
cd deploy/fog
cp .env.example .env && nano .env        # cambia las claves; mismos API_CPUS y API_MEMORIA que la nube
docker compose --profile monitoreo up -d --build
curl localhost:8000/health               # debe decir "arquitectura": "fog"
```

## 3. Operación
- Conecta el servidor a la **UPS** antes de los experimentos.
- Respaldo diario de la base:
  `docker compose exec db pg_dump -U agrismart agrismart | gzip > /respaldos/agrismart_$(date +%F).sql.gz`
- Si el servidor tiene más núcleos que la instancia de AWS, no importa: el límite `API_CPUS` iguala las condiciones del servicio.
