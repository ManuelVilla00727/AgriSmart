# C · Híbrida edge–fog–cloud (grupos G5 y G4)

Combina las otras dos: el fog (servidor HP) calcula las zonas y guarda los datos; el sincronizador envía una copia a la nube cuando hay internet; los nodos guardan las lecturas si se pierde el enlace.

## 1. Lado nube (en la EC2)
Usa `deploy/cloud` **sin** el perfil `broker`:
```bash
cd deploy/cloud && docker compose --profile monitoreo up -d --build
```
En el grupo de seguridad de AWS permite el puerto 8000 solo desde la IP pública de la universidad.

## 2. Lado fog (en el servidor HP)
Si ya corre `deploy/fog`, detenlo primero (`docker compose down` en esa carpeta): este despliegue lo incluye.
```bash
cd /opt/agrismart/deploy/hybrid
cp .env.example .env && nano .env      # CLOUD_API_URL=http://IP_PUBLICA_EC2:8000 y las claves
docker compose --profile monitoreo up -d --build
curl localhost:8000/health             # debe decir "arquitectura": "hibrida"
docker compose logs -f sync            # debe mostrar "Sincronizadas N lecturas"
```

## 3. Lado edge
Los nodos y el gateway usan el firmware de `edge/firmware`. El gateway apunta al MQTT del servidor HP (`MQTT_HOST` = IP del servidor).

## 4. Comprobar la sincronización ante un corte
1. Con el simulador corriendo, corta la salida a internet del servidor HP:
   `sudo ../../experiments/fallos/red.sh corte_temporal eth0 120`
2. Durante el corte: `curl localhost:8000/health` sigue respondiendo y `agrismart_sync_pendientes` crece en Prometheus.
3. Al volver la red, los pendientes bajan a 0 y `GET /v1/lecturas/resumen` en la nube y en el fog muestra los mismos totales.

## 5. Seguridad pendiente (mejora sugerida)
La comunicación fog→nube va por HTTP. Para producción: HTTPS con un certificado (por ejemplo, un proxy Nginx con Let's Encrypt en la EC2) y un token en `CLOUD_API_TOKEN`. Para el artículo basta con restringir el puerto a la IP de la universidad y declararlo como limitación.
