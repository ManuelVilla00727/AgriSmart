"""Ingesta MQTT -> API.

Se suscribe a agrismart/lecturas/# y envía las lecturas en lotes al endpoint /v1/lecturas
del servicio. Corre junto al broker: en AWS (cloud), en los servidores HP (fog e híbrida).

Mensaje esperado (JSON) que publica el gateway o el simulador:
  {"nodo_id":"n01","secuencia":152,"medido_en":"2026-11-09T15:04:05Z",
   "humedad_suelo":31.2,"temperatura_suelo":14.8,"temperatura_aire":17.1,
   "humedad_aire":72.0,"bateria_v":3.95,"rssi":-97}
"""
from __future__ import annotations

import json
import logging
import os
import queue
import random
import threading
import time

import httpx
import paho.mqtt.client as mqtt

BROKER = os.getenv("MQTT_HOST", "mosquitto")
PUERTO = int(os.getenv("MQTT_PORT", "1883"))
USUARIO = os.getenv("MQTT_USER")
CLAVE = os.getenv("MQTT_PASS")
TOPICO = os.getenv("MQTT_TOPIC", "agrismart/lecturas/#")
API = os.getenv("API_URL", "http://api:8000")
LOTE = int(os.getenv("TAMANO_LOTE", "100"))
ESPERA = float(os.getenv("ESPERA_LOTE_S", "1.0"))

logging.basicConfig(level=logging.INFO, format="%(asctime)s ingest %(levelname)s %(message)s")
log = logging.getLogger()
cola: queue.Queue[dict] = queue.Queue(maxsize=100_000)


def al_conectar(cliente, _u, _f, codigo, _p=None):
    log.info("Conectado al broker (código %s); suscrito a %s", codigo, TOPICO)
    cliente.subscribe(TOPICO, qos=1)


def al_mensaje(_c, _u, msg):
    try:
        cola.put_nowait(json.loads(msg.payload))
    except (json.JSONDecodeError, queue.Full) as e:
        log.warning("Mensaje descartado en %s: %s", msg.topic, e)


def enviar(lote: list[dict]) -> None:
    """Reintenta con backoff exponencial y jitter (patrón visto en DAE 08)."""
    intento = 0
    while True:
        try:
            r = httpx.post(f"{API}/v1/lecturas", json={"origen": "gateway", "lecturas": lote}, timeout=10)
            r.raise_for_status()
            log.info("Lote enviado: %s", r.json())
            return
        except httpx.HTTPError as e:
            intento += 1
            espera = min(60, 2 ** intento) * random.uniform(0.5, 1.0)
            log.warning("Fallo al enviar (%s). Reintento %d en %.1f s", e, intento, espera)
            time.sleep(espera)


def despachador():
    while True:
        lote = [cola.get()]
        limite = time.monotonic() + ESPERA
        while len(lote) < LOTE and time.monotonic() < limite:
            try:
                lote.append(cola.get(timeout=max(0.0, limite - time.monotonic())))
            except queue.Empty:
                break
        enviar(lote)


def main():
    threading.Thread(target=despachador, daemon=True).start()
    cliente = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id="agrismart-ingest", clean_session=False)
    if USUARIO:
        cliente.username_pw_set(USUARIO, CLAVE)
    cliente.on_connect = al_conectar
    cliente.on_message = al_mensaje
    cliente.reconnect_delay_set(min_delay=1, max_delay=60)
    while True:
        try:
            cliente.connect(BROKER, PUERTO, keepalive=30)
            cliente.loop_forever()
        except OSError as e:
            log.warning("Broker no disponible (%s); reintento en 5 s", e)
            time.sleep(5)


if __name__ == "__main__":
    main()
