"""Simulador de nodos edge (grupos G5 y G6).

Emula N nodos ESP32 que publican lecturas por MQTT con store-and-forward: si el broker
no está disponible, las lecturas se guardan en una cola local (SQLite) y se envían
cuando vuelve la conexión. Sirve para:
  - probar las tres arquitecturas en el laboratorio sin hardware;
  - generar carga con muchos nodos (por ejemplo, 200);
  - medir pérdida de datos y tiempo de recuperación ante cortes de red.

Ejemplos:
  python simulador_nodos.py --broker 192.168.1.50 --usuario agrismart --clave XXX --nodos 50 --intervalo 5
  python simulador_nodos.py --broker localhost --nodos 4 --duracion 600 --sin-cola   # sin store-and-forward
Al terminar imprime cuántas lecturas generó, envió y dejó pendientes (y las guarda en un CSV).
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import random
import sqlite3
import threading
import time
from datetime import datetime, timezone

import paho.mqtt.client as mqtt


class ColaLocal:
    def __init__(self, ruta: str):
        self.con = sqlite3.connect(ruta, check_same_thread=False)
        self.con.execute("CREATE TABLE IF NOT EXISTS cola (nodo TEXT, seq INTEGER, json TEXT, PRIMARY KEY(nodo, seq))")
        self.lock = threading.Lock()

    def poner(self, nodo, seq, payload):
        with self.lock:
            self.con.execute("INSERT OR REPLACE INTO cola VALUES (?,?,?)", (nodo, seq, payload))
            self.con.commit()

    def primeras(self, n=200):
        with self.lock:
            return self.con.execute("SELECT nodo, seq, json FROM cola ORDER BY rowid LIMIT ?", (n,)).fetchall()

    def quitar(self, nodo, seq):
        with self.lock:
            self.con.execute("DELETE FROM cola WHERE nodo=? AND seq=?", (nodo, seq))
            self.con.commit()

    def tamano(self):
        with self.lock:
            return self.con.execute("SELECT count(*) FROM cola").fetchone()[0]


def lectura(nodo: str, seq: int, t: float) -> dict:
    """Valores realistas con ciclo diario (Latacunga, ~2800 m s. n. m.)."""
    hora = (t / 3600) % 24
    diurno = math.sin((hora - 6) / 24 * 2 * math.pi)
    base = int("".join(ch for ch in nodo[-3:] if ch.isdigit()) or 1)
    return {
        "nodo_id": nodo, "secuencia": seq,
        "medido_en": datetime.fromtimestamp(t, timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "humedad_suelo": round(28 + base % 7 + random.gauss(0, 0.8), 1),
        "temperatura_suelo": round(12 + 3 * diurno + random.gauss(0, 0.3), 1),
        "temperatura_aire": round(13 + 6 * diurno + random.gauss(0, 0.5), 1),
        "humedad_aire": round(75 - 15 * diurno + random.gauss(0, 2), 1),
        "bateria_v": round(3.9 + random.gauss(0, 0.03), 2),
        "rssi": round(-95 + random.gauss(0, 4), 0),
    }


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--broker", default="localhost")
    ap.add_argument("--puerto", type=int, default=1883)
    ap.add_argument("--usuario")
    ap.add_argument("--clave")
    ap.add_argument("--nodos", type=int, default=4)
    ap.add_argument("--prefijo", default="n", help="prefijo de los nodos; usa uno distinto por corrida")
    ap.add_argument("--intervalo", type=float, default=10, help="segundos entre lecturas de cada nodo")
    ap.add_argument("--duracion", type=float, default=300, help="segundos de simulación (0 = sin fin)")
    ap.add_argument("--sin-cola", action="store_true", help="desactiva store-and-forward (para comparar)")
    ap.add_argument("--cola", default="cola_simulador.sqlite")
    ap.add_argument("--salida", default="resultado_simulador.csv")
    a = ap.parse_args()

    cola = ColaLocal(a.cola)
    conectado = threading.Event()
    stats = {"generadas": 0, "enviadas": 0, "perdidas": 0}

    cli = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=f"simulador-{random.randint(0, 99999)}")
    if a.usuario:
        cli.username_pw_set(a.usuario, a.clave)
    cli.on_connect = lambda c, u, f, rc, p=None: (conectado.set() if not rc.is_failure else None)
    cli.on_disconnect = lambda c, u, f, rc, p=None: conectado.clear()
    cli.reconnect_delay_set(1, 30)
    cli.connect_async(a.broker, a.puerto, keepalive=15)
    cli.loop_start()

    def publicar(nodo, seq, payload) -> bool:
        if not conectado.is_set():
            return False
        info = cli.publish(f"agrismart/lecturas/{nodo}", payload, qos=1)
        try:
            info.wait_for_publish(timeout=5)
        except (ValueError, RuntimeError):
            return False
        return info.is_published()

    nodos = [f"{a.prefijo}{i:02d}" for i in range(1, a.nodos + 1)]
    seqs = {n: 0 for n in nodos}
    inicio = time.time()
    proxima = {n: inicio + random.uniform(0, a.intervalo) for n in nodos}
    try:
        while a.duracion == 0 or time.time() - inicio < a.duracion:
            ahora = time.time()
            for n in nodos:
                if ahora >= proxima[n]:
                    proxima[n] += a.intervalo
                    seqs[n] += 1
                    payload = json.dumps(lectura(n, seqs[n], ahora))
                    stats["generadas"] += 1
                    if a.sin_cola:
                        if publicar(n, seqs[n], payload):
                            stats["enviadas"] += 1
                        else:
                            stats["perdidas"] += 1
                    else:
                        cola.poner(n, seqs[n], payload)
            if not a.sin_cola and conectado.is_set():
                for n, s, p in cola.primeras():
                    if not publicar(n, s, p):
                        break
                    cola.quitar(n, s)
                    stats["enviadas"] += 1
            time.sleep(0.05)
    except KeyboardInterrupt:
        pass
    pendientes = cola.tamano()
    cli.loop_stop()
    print(f"Generadas: {stats['generadas']} | enviadas: {stats['enviadas']} | "
          f"pendientes en cola: {pendientes} | perdidas (sin cola): {stats['perdidas']}")
    nuevo = False
    try:
        open(a.salida).close()
    except FileNotFoundError:
        nuevo = True
    with open(a.salida, "a", newline="") as f:
        w = csv.writer(f)
        if nuevo:
            w.writerow(["fecha", "broker", "nodos", "intervalo_s", "duracion_s", "store_and_forward",
                        "generadas", "enviadas", "pendientes", "perdidas"])
        w.writerow([datetime.now().isoformat(timespec="seconds"), a.broker, a.nodos, a.intervalo, a.duracion,
                    not a.sin_cola, stats["generadas"], stats["enviadas"], pendientes, stats["perdidas"]])


if __name__ == "__main__":
    main()
