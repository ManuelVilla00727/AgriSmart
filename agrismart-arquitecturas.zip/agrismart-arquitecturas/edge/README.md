# Edge: nodos, gateway y simulador (grupo G5)

## Material por nodo
| Componente | Cantidad |
|---|---|
| Placa ESP32 con LoRa a 915 MHz (Heltec WiFi LoRa 32 V3 o LilyGO T3 LoRa32), con antena | 1 |
| Sensor capacitivo de humedad de suelo v2.0 | 1 |
| Sonda DS18B20 sumergible con módulo adaptador | 1 |
| Sensor SHT31 (temperatura y humedad del aire) | 1 |
| Power bank y cable USB (visitas de campo) | 1 |

Se necesitan 4 nodos y 1 placa adicional como gateway (si no hay gateway LoRaWAN).

## Conexiones (verifica con el diagrama de tu placa)
| Sensor | Pin del sensor | Heltec V3 | LilyGO T3 V1.6.1 |
|---|---|---|---|
| Humedad de suelo | AOUT | GPIO 6 | GPIO 36 |
| Humedad de suelo | VCC / GND | 3V3 / GND | 3V3 / GND |
| DS18B20 (módulo) | DATA | GPIO 4 | GPIO 13 |
| DS18B20 (módulo) | VCC / GND | 3V3 / GND | 3V3 / GND |
| SHT31 | SDA / SCL | GPIO 17 / 18 | GPIO 21 / 22 |
| SHT31 | VIN / GND | 3V3 / GND | 3V3 / GND |

En la Heltec V3 el SHT31 comparte el bus I2C de la pantalla (dirección 0x44, no hay conflicto).

## Cargar el firmware
1. Arduino IDE 2 con la placa "esp32 by Espressif Systems" (v3.x).
2. Librerías: RadioLib, ArduinoJson (v7), OneWire, DallasTemperature, Adafruit SHT31 Library, PubSubClient.
3. En cada archivo `.ino`, elige la placa (`#define PLACA_HELTEC_V3` o `PLACA_LILYGO_T3`).
4. `gateway_lora_mqtt.ino`: pon el Wi-Fi, la IP del broker y la clave MQTT.
5. `nodo_sensor.ino`: cambia `NODO_ID` en cada nodo (`n01` a `n04`).
6. Mismo `FRECUENCIA_MHZ` (915) y mismo `SF` en nodos y gateway.

## Calibrar el sensor de humedad
Abre el Monitor Serie, agrega temporalmente `Serial.println(analogRead(PIN_HUMEDAD));` y anota el valor con el sensor en el aire (`ADC_SECO`) y sumergido en agua hasta la línea (`ADC_MOJADO`). Escríbelos en el firmware. Documenta los valores de cada sensor.

## Cómo funciona el store-and-forward
1. Cada lectura se guarda en la flash (`/cola.txt`) con su número de secuencia.
2. El nodo envía las pendientes, de la más antigua a la más nueva, y espera el ACK `A|n01|152`.
3. El gateway solo responde ACK si logró publicar en MQTT. Sin broker o sin Wi-Fi no hay ACK y la lectura se queda en el nodo.
4. La secuencia sobrevive a reinicios (se guarda en NVS). Junto con la idempotencia de la API, evita duplicados.
5. Al enviar, el nodo indica la edad de la lectura en segundos; el gateway calcula la hora real con NTP. **Limitación:** si el nodo se reinicia, las lecturas pendientes pierden su hora original y se registran con la hora de llegada.

Prueba obligatoria (S6–S8): apaga el gateway 10 minutos, vuelve a encenderlo y verifica en `GET /v1/lecturas/resumen` que no falta ninguna secuencia.

## Simulador (sin hardware)
```bash
pip install paho-mqtt
python simulador/simulador_nodos.py --broker IP_BROKER --usuario agrismart --clave XXX --nodos 20 --intervalo 5 --duracion 600
python simulador/simulador_nodos.py --broker IP_BROKER --nodos 20 --sin-cola     # sin store-and-forward, para comparar
```
El simulador se usa en los experimentos de resiliencia: permite generar la misma carga en las tres arquitecturas.
