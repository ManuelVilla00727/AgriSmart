/*
  AgriSmart · Nodo sensor ESP32 + LoRa (grupo G5)

  Mide humedad de suelo (sensor capacitivo v2.0), temperatura de suelo (DS18B20) y
  temperatura/humedad del aire (SHT31), y envía por LoRa al gateway.

  Store-and-forward: cada lectura se guarda primero en la memoria flash (LittleFS).
  Solo se borra cuando el gateway confirma con un ACK. Si no hay enlace, las lecturas
  se acumulan y se envían cuando vuelve la conexión (las más antiguas primero).

  Placas soportadas (elige una abajo):
    - Heltec WiFi LoRa 32 V3  (radio SX1262)
    - LilyGO T3 LoRa32 V1.6.1 (radio SX1276)
  VERIFICA los pines con el diagrama de tu placa antes de conectar sensores.

  Librerías (Gestor de librerías de Arduino IDE):
    RadioLib, ArduinoJson (v7), OneWire, DallasTemperature, Adafruit SHT31 Library
  Placa: "esp32 by Espressif Systems" (v3.x)
*/

#define PLACA_HELTEC_V3      // <- comenta esta línea y descomenta la siguiente si usas LilyGO
// #define PLACA_LILYGO_T3

#include <RadioLib.h>
#include <ArduinoJson.h>
#include <LittleFS.h>
#include <Preferences.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <Wire.h>
#include <Adafruit_SHT31.h>

// ------------------------- CONFIGURACIÓN -------------------------
const char* NODO_ID          = "n01";      // único por nodo: n01, n02, n03, n04
const uint32_t INTERVALO_MS  = 60000;      // una lectura por minuto
const float FRECUENCIA_MHZ   = 915.0;      // banda usada en Ecuador
const int   SF               = 7;          // factor de dispersión (7 = rápido, 12 = más alcance)
const int   MAX_COLA         = 1000;       // lecturas máximas guardadas sin enlace
const uint16_t ESPERA_ACK_MS = 1500;
const int   REINTENTOS       = 3;

// Calibración del sensor capacitivo (mídela con tu sensor: en aire seco y en agua)
const int ADC_SECO   = 3000;
const int ADC_MOJADO = 1300;

#ifdef PLACA_HELTEC_V3
  // SX1262: NSS, DIO1, RESET, BUSY
  SX1262 radio = new Module(8, 14, 12, 13);
  const int PIN_SCK = 9, PIN_MISO = 11, PIN_MOSI = 10;
  const int PIN_HUMEDAD = 6;      // entrada analógica (ADC1)
  const int PIN_DS18B20 = 4;
  const int PIN_SDA = 17, PIN_SCL = 18;   // bus I2C compartido con la pantalla
  const int PIN_VEXT = 36;                // alimentación de periféricos (LOW = encendido)
#endif
#ifdef PLACA_LILYGO_T3
  // SX1276: NSS, DIO0, RESET, DIO1
  SX1276 radio = new Module(18, 26, 23, 33);
  const int PIN_SCK = 5, PIN_MISO = 19, PIN_MOSI = 27;
  const int PIN_HUMEDAD = 36;
  const int PIN_DS18B20 = 13;
  const int PIN_SDA = 21, PIN_SCL = 22;
  const int PIN_VEXT = -1;
#endif
// -----------------------------------------------------------------

OneWire oneWire(PIN_DS18B20);
DallasTemperature ds18b20(&oneWire);
Adafruit_SHT31 sht31;
Preferences prefs;

uint32_t secuencia = 0;
uint32_t ultimaLectura = 0;
const char* ARCHIVO_COLA = "/cola.txt";

// ----------------------- Cola en flash ----------------------------
// Cada línea: secuencia;millis_medicion;json
int contarCola() {
  File f = LittleFS.open(ARCHIVO_COLA, "r");
  if (!f) return 0;
  int n = 0;
  while (f.available()) { if (f.read() == '\n') n++; }
  f.close();
  return n;
}

void encolar(const String& linea) {
  if (contarCola() >= MAX_COLA) {
    // Cola llena: se descarta la más antigua para guardar la nueva.
    File f = LittleFS.open(ARCHIVO_COLA, "r");
    f.readStringUntil('\n');
    String resto = f.readString();
    f.close();
    File w = LittleFS.open(ARCHIVO_COLA, "w");
    w.print(resto);
    w.close();
  }
  File f = LittleFS.open(ARCHIVO_COLA, "a");
  f.println(linea);
  f.close();
}

bool leerPrimera(String& linea) {
  File f = LittleFS.open(ARCHIVO_COLA, "r");
  if (!f || !f.available()) { if (f) f.close(); return false; }
  linea = f.readStringUntil('\n');
  f.close();
  linea.trim();
  return linea.length() > 0;
}

void quitarPrimera() {
  File f = LittleFS.open(ARCHIVO_COLA, "r");
  if (!f) return;
  f.readStringUntil('\n');
  String resto = f.readString();
  f.close();
  File w = LittleFS.open(ARCHIVO_COLA, "w");
  w.print(resto);
  w.close();
}

// ------------------------- Sensores ------------------------------
float leerHumedadSuelo() {
  long suma = 0;
  for (int i = 0; i < 10; i++) { suma += analogRead(PIN_HUMEDAD); delay(5); }
  int adc = suma / 10;
  float pct = 100.0 * (ADC_SECO - adc) / (float)(ADC_SECO - ADC_MOJADO);
  return constrain(pct, 0.0, 100.0);
}

String medir() {
  ds18b20.requestTemperatures();
  float tSuelo = ds18b20.getTempCByIndex(0);
  float tAire = sht31.readTemperature();
  float hAire = sht31.readHumidity();

  JsonDocument doc;
  doc["n"] = NODO_ID;
  doc["s"] = secuencia;
  doc["hs"] = round(leerHumedadSuelo() * 10) / 10.0;
  if (tSuelo > -100) doc["ts"] = round(tSuelo * 10) / 10.0;      // -127 = sensor desconectado
  if (!isnan(tAire)) doc["ta"] = round(tAire * 10) / 10.0;
  if (!isnan(hAire)) doc["ha"] = round(hAire * 10) / 10.0;
  String json;
  serializeJson(doc, json);
  return json;
}

// --------------------------- Envío --------------------------------
// Al enviar se agrega "e": segundos desde que se midió. El gateway calcula la hora real
// de medición restando esa edad a su reloj (sincronizado por NTP).
bool enviarConAck(const String& linea) {
  int p1 = linea.indexOf(';');
  int p2 = linea.indexOf(';', p1 + 1);
  uint32_t seq = linea.substring(0, p1).toInt();
  uint32_t msMedida = linea.substring(p1 + 1, p2).toInt();
  String json = linea.substring(p2 + 1);

  JsonDocument doc;
  if (deserializeJson(doc, json)) return true;  // línea corrupta: se descarta
  // Si el nodo se reinició, millis() volvió a cero y la edad no es confiable (-1).
  doc["e"] = (msMedida <= millis()) ? (int32_t)((millis() - msMedida) / 1000) : -1;
  String paquete;
  serializeJson(doc, paquete);

  for (int intento = 0; intento < REINTENTOS; intento++) {
    if (radio.transmit(paquete) != RADIOLIB_ERR_NONE) { delay(200); continue; }
    String ack;
    uint32_t t0 = millis();
    while (millis() - t0 < ESPERA_ACK_MS) {
      int estado = radio.receive(ack, 0);
      if (estado == RADIOLIB_ERR_NONE) {
        String esperado = String("A|") + NODO_ID + "|" + seq;
        if (ack == esperado) return true;
      }
    }
    delay(random(200, 800));  // jitter: evita que varios nodos choquen al reintentar
  }
  return false;
}

void vaciarCola() {
  String linea;
  int enviadas = 0;
  while (leerPrimera(linea) && enviadas < 20) {   // máximo 20 por ciclo para no saturar el canal
    if (!enviarConAck(linea)) {
      Serial.printf("Sin ACK. Pendientes en cola: %d\n", contarCola());
      return;
    }
    quitarPrimera();
    enviadas++;
  }
  if (enviadas) Serial.printf("Enviadas %d. Pendientes: %d\n", enviadas, contarCola());
}

// ---------------------------- Setup -------------------------------
void setup() {
  Serial.begin(115200);
  if (PIN_VEXT >= 0) { pinMode(PIN_VEXT, OUTPUT); digitalWrite(PIN_VEXT, LOW); delay(100); }
  analogReadResolution(12);

  if (!LittleFS.begin(true)) Serial.println("ERROR: no se pudo montar LittleFS");
  prefs.begin("agrismart", false);
  secuencia = prefs.getUInt("seq", 0);   // el contador sobrevive a reinicios

  Wire.begin(PIN_SDA, PIN_SCL);
  if (!sht31.begin(0x44)) Serial.println("AVISO: SHT31 no encontrado");
  ds18b20.begin();

  SPI.begin(PIN_SCK, PIN_MISO, PIN_MOSI);
  int estado = radio.begin(FRECUENCIA_MHZ, 125.0, SF, 5, 0x34, 14);
  Serial.printf("Radio: %s\n", estado == RADIOLIB_ERR_NONE ? "OK" : "ERROR");
  Serial.printf("Nodo %s listo. Secuencia actual %u. En cola: %d\n", NODO_ID, secuencia, contarCola());
}

void loop() {
  if (ultimaLectura == 0 || millis() - ultimaLectura >= INTERVALO_MS) {
    ultimaLectura = millis();
    secuencia++;
    prefs.putUInt("seq", secuencia);
    String json = medir();
    encolar(String(secuencia) + ";" + String(millis()) + ";" + json);
    Serial.println("Medido: " + json);
    vaciarCola();
  }
  delay(100);
}
