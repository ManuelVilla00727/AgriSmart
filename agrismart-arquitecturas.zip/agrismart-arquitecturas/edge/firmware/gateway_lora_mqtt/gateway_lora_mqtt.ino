/*
  AgriSmart · Gateway LoRa -> MQTT (grupo G5)

  Una placa ESP32 LoRa (de las que ya tienen) hace de receptor si no hay gateway LoRaWAN.
  Recibe los paquetes de los nodos, calcula la hora real de medición, publica en MQTT y
  SOLO responde ACK al nodo si la publicación fue exitosa. Así, si el broker no está
  disponible, el dato se queda guardado en el nodo (store-and-forward en el edge).

  El broker cambia según la arquitectura:
    Cloud-céntrica -> MQTT en la instancia EC2 (por internet)
    Fog e híbrida  -> MQTT en el servidor HP (red local)

  Librerías: RadioLib, ArduinoJson (v7), PubSubClient
*/

#define PLACA_HELTEC_V3
// #define PLACA_LILYGO_T3

#include <WiFi.h>
#include <PubSubClient.h>
#include <RadioLib.h>
#include <ArduinoJson.h>
#include <time.h>

// ------------------------- CONFIGURACIÓN -------------------------
const char* WIFI_SSID   = "TU_RED_WIFI";
const char* WIFI_CLAVE  = "TU_CLAVE_WIFI";
const char* MQTT_HOST   = "192.168.1.50";   // IP del servidor HP o de la EC2
const int   MQTT_PUERTO = 1883;
const char* MQTT_USUARIO = "agrismart";
const char* MQTT_CLAVE   = "CLAVE_DEL_BROKER";
const float FRECUENCIA_MHZ = 915.0;
const int   SF = 7;                          // debe ser igual al de los nodos
// -----------------------------------------------------------------

#ifdef PLACA_HELTEC_V3
  SX1262 radio = new Module(8, 14, 12, 13);
  const int PIN_SCK = 9, PIN_MISO = 11, PIN_MOSI = 10;
#endif
#ifdef PLACA_LILYGO_T3
  SX1276 radio = new Module(18, 26, 23, 33);
  const int PIN_SCK = 5, PIN_MISO = 19, PIN_MOSI = 27;
#endif

WiFiClient red;
PubSubClient mqtt(red);

void conectarWifi() {
  if (WiFi.status() == WL_CONNECTED) return;
  WiFi.begin(WIFI_SSID, WIFI_CLAVE);
  uint32_t t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t0 < 15000) delay(250);
  if (WiFi.status() == WL_CONNECTED) {
    configTime(0, 0, "pool.ntp.org", "time.google.com");   // hora en UTC
    Serial.println("WiFi OK: " + WiFi.localIP().toString());
  }
}

bool conectarMqtt() {
  if (mqtt.connected()) return true;
  String id = "gateway-" + String((uint32_t)ESP.getEfuseMac(), HEX);
  return mqtt.connect(id.c_str(), MQTT_USUARIO, MQTT_CLAVE);
}

String horaISO(time_t t) {
  struct tm tmUtc;
  gmtime_r(&t, &tmUtc);
  char buf[25];
  strftime(buf, sizeof(buf), "%Y-%m-%dT%H:%M:%SZ", &tmUtc);
  return String(buf);
}

void setup() {
  Serial.begin(115200);
  SPI.begin(PIN_SCK, PIN_MISO, PIN_MOSI);
  int estado = radio.begin(FRECUENCIA_MHZ, 125.0, SF, 5, 0x34, 14);
  Serial.printf("Radio: %s\n", estado == RADIOLIB_ERR_NONE ? "OK" : "ERROR");
  mqtt.setServer(MQTT_HOST, MQTT_PUERTO);
  mqtt.setBufferSize(512);
  conectarWifi();
}

void loop() {
  conectarWifi();
  if (WiFi.status() == WL_CONNECTED) conectarMqtt();
  mqtt.loop();

  String paquete;
  if (radio.receive(paquete, 0) != RADIOLIB_ERR_NONE) return;
  float rssi = radio.getRSSI();

  JsonDocument in;
  if (deserializeJson(in, paquete)) { Serial.println("Paquete inválido"); return; }
  const char* nodo = in["n"] | "desconocido";
  uint32_t seq = in["s"] | 0;
  int edad = in["e"] | -1;

  time_t ahora = time(nullptr);
  if (ahora < 1700000000) { Serial.println("Sin hora NTP todavía; no se confirma"); return; }
  time_t medido = (edad >= 0) ? ahora - edad : ahora;

  JsonDocument out;
  out["nodo_id"] = nodo;
  out["secuencia"] = seq;
  out["medido_en"] = horaISO(medido);
  if (!in["hs"].isNull()) out["humedad_suelo"] = in["hs"];
  if (!in["ts"].isNull()) out["temperatura_suelo"] = in["ts"];
  if (!in["ta"].isNull()) out["temperatura_aire"] = in["ta"];
  if (!in["ha"].isNull()) out["humedad_aire"] = in["ha"];
  out["rssi"] = rssi;
  String json;
  serializeJson(out, json);

  String topico = String("agrismart/lecturas/") + nodo;
  if (mqtt.connected() && mqtt.publish(topico.c_str(), json.c_str())) {
    String ack = String("A|") + nodo + "|" + seq;
    delay(50);
    radio.transmit(ack);
    Serial.println("Publicado y confirmado: " + json);
  } else {
    // Sin broker: no se responde ACK y el nodo conserva la lectura.
    Serial.println("Broker no disponible; el nodo reintentará");
  }
}
