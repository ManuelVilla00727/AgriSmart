# Las tres arquitecturas

El artículo responde una pregunta: **¿dónde conviene procesar los datos de suelo para delimitar zonas de manejo cuando la conexión rural es intermitente?** Para responderla se construyen tres arquitecturas que hacen exactamente lo mismo y se comparan con experimentos.

## Lo que comparten las tres

- **El servicio de zonas** (`service/`): recibe celdas de suelo y devuelve a qué zona pertenece cada una. Es la misma imagen Docker en las tres.
- **El algoritmo**: k-means con restricciones de tamaño (`kmeans_tamano`), con k-means simple como línea base y un MILP exacto para tamaños pequeños.
- **Los datos**: celdas de SoilGrids de la parroquia 11 de Noviembre más fósforo y potasio sintéticos.
- **Los nodos**: ESP32 con LoRa que miden humedad y temperatura de suelo y del aire.
- **Los límites de recursos del servicio**: los mismos CPU y memoria (`API_CPUS`, `API_MEMORIA`), para que la comparación sea justa.

## A · Cloud-céntrica

```mermaid
flowchart LR
  N[Nodos ESP32] -- LoRa --> G[Gateway ESP32]
  G -- MQTT por internet --> M
  subgraph AWS [AWS · EC2]
    M[Mosquitto] --> I[Ingesta] --> API[Servicio de zonas] --> DB[(PostGIS)]
  end
  U[Usuario / k6] -- HTTP por internet --> API
```

Todo se procesa y se guarda en la nube. En el campo y en la universidad solo se transmite.

- **A favor:** escala contratando más capacidad; no hay servidores propios que mantener.
- **En contra:** sin internet no hay servicio; cada solicitud viaja a un centro de datos lejano; se paga por uso.
- **Pregunta que responde:** ¿cuánto cuesta, en latencia y en datos, depender de internet?

## B · Fog on-premise

```mermaid
flowchart LR
  N[Nodos ESP32] -- LoRa --> G[Gateway ESP32]
  G -- MQTT red local --> M
  subgraph HP [Servidor HP · universidad]
    M[Mosquitto] --> I[Ingesta] --> API[Servicio de zonas] --> DB[(PostGIS)]
  end
  U[Usuario / k6] -- HTTP red local --> API
```

Todo se procesa y se guarda en el servidor HP, cerca de los datos. No se usa la nube.

- **A favor:** baja latencia; funciona sin internet; sin costo mensual.
- **En contra:** la capacidad es la del servidor; si falla el servidor o la energía, se detiene todo; el respaldo es manual.
- **Pregunta que responde:** ¿cuánto se gana procesando localmente y dónde se satura?

## C · Híbrida edge–fog–cloud

```mermaid
flowchart LR
  subgraph Edge [Edge · campo]
    N[Nodos ESP32<br/>store-and-forward]
  end
  N -- LoRa --> G[Gateway ESP32]
  G -- MQTT red local --> M
  subgraph HP [Fog · servidor HP]
    M[Mosquitto] --> I[Ingesta] --> API[Servicio de zonas] --> DB[(PostGIS)]
    DB --> S[Sincronizador<br/>outbox]
  end
  S -- HTTPS cuando hay internet --> APIc
  subgraph AWS [Cloud · AWS]
    APIc[Servicio de zonas] --> DBc[(PostGIS<br/>respaldo y analítica)]
  end
```

Cada nivel hace lo que mejor sabe hacer:

1. **Edge:** el nodo guarda cada lectura en su memoria flash y solo la borra cuando el gateway confirma (ACK). Si no hay enlace, acumula hasta 1000 lecturas.
2. **Fog:** calcula las zonas localmente, así que responde rápido y sin internet. Guarda las lecturas marcadas como pendientes de sincronizar.
3. **Cloud:** recibe una copia. El sincronizador envía lotes y solo marca como sincronizado lo que la nube confirma. Como la API ignora duplicados (`nodo_id` + `secuencia`), reenviar no daña nada.

- **A favor:** rapidez y autonomía del fog con el respaldo de la nube; no pierde datos ante cortes.
- **En contra:** es la más compleja; hay que vigilar la cola de sincronización y la consistencia entre fog y nube.
- **Pregunta que responde:** ¿compensa la complejidad adicional en zonas con conectividad intermitente?

## Qué se mide

| Experimento | Variables que cambian | Qué se mide |
|---|---|---|
| Rendimiento | Arquitectura (3) × tamaño del problema (300, 1000, 2500 celdas) × usuarios concurrentes (1, 8, 32) × 30 repeticiones | Latencia p50/p95/p99, throughput, tasa de error, CPU y memoria, costo por trabajo |
| Resiliencia | Arquitectura (3) × duración del corte de red (60 y 300 s) × 10 repeticiones | Lecturas perdidas, tiempo de recuperación, máximo de lecturas pendientes |
| Equivalencia | Las tres arquitecturas con la misma solicitud | Que las zonas y sus métricas de calidad sean idénticas (control de validez) |

## Patrones de la maestría que aparecen

| Patrón | Dónde |
|---|---|
| Store-and-forward | Firmware del nodo y simulador |
| Outbox | Sincronizador fog → nube |
| Idempotencia | `POST /v1/lecturas` con clave `(nodo_id, secuencia)` |
| Retry con backoff exponencial y jitter | Ingesta, sincronizador y nodos |
| Publicar/suscribir | MQTT entre gateway e ingesta |
| Strategy | Selección del método de clustering (`metodo`) |
| API-First | Contrato común documentado en `/docs` (OpenAPI) |
| Observabilidad | Métricas Prometheus en `/metrics`, Grafana |
| Mínimo privilegio | Contenedores con usuario sin privilegios, claves en `.env` |
