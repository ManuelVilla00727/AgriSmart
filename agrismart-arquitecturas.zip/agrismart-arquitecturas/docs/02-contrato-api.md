# Contrato de la API (igual en las tres arquitecturas)

La documentación interactiva completa (OpenAPI) está en `http://HOST:8000/docs` cuando el servicio corre.

## `GET /health`
Estado del servicio. Úsalo para confirmar a qué arquitectura apuntas antes de un experimento.
```json
{"estado": "ok", "arquitectura": "fog", "nodo": "a1b2c3", "version": "1.0.0", "base_datos": true}
```

## `POST /v1/zonas`
Calcula las zonas de manejo.

| Campo | Tipo | Descripción |
|---|---|---|
| `celdas` | lista | `id`, `lat`, `lon` y las variables de suelo (`ph`, `nitrogeno`, `carbono_organico`, `arcilla`, `arena`, `limo`, `fosforo`, `potasio`) |
| `k` | entero 2–50 | Número de zonas |
| `metodo` | texto | `kmeans` (línea base), `kmeans_tamano` (principal), `milp` (exacto, hasta 400 celdas) |
| `tamano_min`, `tamano_max` | entero | Celdas mínimas y máximas por zona. Obligatorios salvo en `kmeans` |
| `variables` | lista | Variables que se usan para agrupar |
| `peso_espacial` | 0–5 | Peso de las coordenadas: con 0 las zonas pueden quedar dispersas |
| `semilla` | entero | Misma semilla, mismo resultado (reproducibilidad) |
| `etiqueta_experimento` | texto | Escenario, queda en la tabla `trabajos` |

Respuesta (resumida; ejemplo real con 1000 celdas sintéticas y 8 zonas):
```json
{"trabajo_id": "…", "metodo": "kmeans_tamano", "k": 8,
 "asignaciones": [{"id": "r0_c0", "zona": 3}, …],
 "metricas": {"tamanos": [133, 132, 132, 132, 118, 121, 116, 116], "varianza_intra": 4928.9,
              "varianza_intra_relativa": 0.657, "silueta": 0.096, "cumplimiento_tamanos": 1.0},
 "estado_solver": "convergio", "iteraciones": 2,
 "tiempo_algoritmo_ms": 148.2, "tiempo_total_ms": 151.0, "arquitectura": "fog", "nodo": "a1b2c3"}
```

Errores: `422` si los datos o los tamaños son imposibles (por ejemplo, 4 zonas de 6 a 8 celdas con 20 celdas); `409` si el MILP no encuentra solución en el tiempo límite.

Límites del servidor: `kmeans_tamano` hasta 3000 celdas por solicitud; `milp` hasta 400. Como referencia, en una computadora de desarrollo `kmeans_tamano` con 8 zonas y ±15 % de holgura tarda unos 0,06 s con 300 celdas, 0,15 s con 1000 y 1,2 s con 2500.

## `POST /v1/lecturas`
Recibe lecturas de los nodos (la usan la ingesta y el sincronizador). Es **idempotente**: si `(nodo_id, secuencia)` ya existe, se ignora.
```json
{"origen": "gateway",
 "lecturas": [{"nodo_id": "n01", "secuencia": 152, "medido_en": "2026-11-09T15:04:05Z",
               "humedad_suelo": 31.2, "temperatura_suelo": 14.8, "temperatura_aire": 17.1,
               "humedad_aire": 72.0, "bateria_v": 3.95, "rssi": -97}]}
```
Respuesta: `{"recibidas": 1, "nuevas": 1, "duplicadas": 0}`

## `GET /v1/lecturas/ultimas?limite=50` y `GET /v1/lecturas/resumen`
Últimas lecturas y conteo por nodo. Si `max_secuencia` es mayor que `recibidas`, faltan lecturas de ese nodo.

## `GET /metrics`
Métricas para Prometheus: `agrismart_solicitudes_total`, `agrismart_zonas_segundos` (histograma), `agrismart_lecturas_total`.

## Mensaje MQTT
Tópico `agrismart/lecturas/<nodo_id>`, cuerpo JSON con los mismos campos de una lectura.
