# Cómo se ejecutan los experimentos

**No se ejecutan experimentos definitivos antes de la aprobación del anteproyecto.** Hasta entonces, solo pruebas.

## Reglas para que los datos sean válidos
1. **Misma versión del servicio** en las tres arquitecturas (imagen `v1.0`, congelada en S13).
2. **Mismos límites de recursos** (`API_CPUS`, `API_MEMORIA`, `API_WORKERS` en `.env`).
3. **Mismas solicitudes** (`experiments/solicitudes/*.json`) y la misma semilla.
4. **La carga se genera desde otra máquina**, nunca desde el servidor que se mide.
5. **Orden aleatorio** de las corridas (`escenarios_*.csv`), con 20 s de pausa entre corridas.
6. Se anota en la bitácora (G8) cualquier evento raro: cortes de luz, actualizaciones, otras cargas en la red.

## Experimento 1 · Rendimiento
```bash
cd experiments
python generar_escenarios.py                 # una sola vez; queda en el repositorio
python ../data/preparar_solicitudes.py --celdas ../data/celdas_completas.csv --tamanos 300 1000 2500
python ejecutar_rendimiento.py --arquitectura fog --api http://IP_FOG:8000
python ejecutar_rendimiento.py --arquitectura cloud --api http://IP_EC2:8000
python ejecutar_rendimiento.py --arquitectura hibrida --api http://IP_FOG:8000
```
810 corridas de 1 minuto (~13,5 horas en total, ~4,5 horas por arquitectura). Si se interrumpe, al volver a ejecutar continúa donde quedó. Resultado: `resultados/rendimiento.csv`.

En la arquitectura híbrida las solicitudes van al **fog** (allí se calculan las zonas); la nube solo recibe la copia de los datos.

## Experimento 2 · Resiliencia
Se mide en la API **donde terminan los datos**: nube (cloud), fog (fog), nube (híbrida: se comprueba que la sincronización recupera todo).

```bash
# Ejemplo: híbrida, corte de 60 s en la salida a internet del servidor HP
python medir_resiliencia.py --arquitectura hibrida --api http://IP_EC2:8000 --broker IP_FOG \
  --usuario agrismart --clave XXX --nodos 20 --intervalo 5 --duracion 600 --inicio-corte 120 --corte-s 60 \
  --comando-corte "ssh admin@IP_FOG sudo /opt/agrismart/experiments/fallos/red.sh corte_temporal eth0 60" \
  --id F001 --rep 1
```
Dónde se corta la red en cada arquitectura:
- **cloud:** el enlace entre el gateway y la EC2 (la salida a internet de la red del laboratorio).
- **fog:** el enlace entre el gateway y el servidor HP (apaga el Wi-Fi del gateway o usa `cortar_contenedor.sh` sobre `mosquitto`).
- **híbrida:** la salida a internet del servidor HP. El fog debe seguir calculando zonas durante el corte.

Repite cada combinación de `escenarios_resiliencia.csv` (60 corridas de ~10 minutos). Resultado: `resultados/resiliencia.csv`.

## Experimento 3 · Equivalencia (control)
Envía la misma solicitud a las tres arquitecturas y compara `asignaciones` y `metricas`: deben ser idénticas. Si no lo son, se detiene todo y se revisa la versión del servicio.

## Análisis
```bash
cd analysis
python analisis.py --rendimiento ../experiments/resultados/rendimiento.csv \
                   --resiliencia ../experiments/resultados/resiliencia.csv
```
Produce las tablas descriptivas, las pruebas estadísticas (ANOVA o Kruskal-Wallis con Holm) y las figuras.
