# Guía por grupo

Cada grupo tiene 5 estudiantes y 240 horas por estudiante (del 9 de noviembre de 2026 al 19 de marzo de 2027). Las semanas coinciden con el cronograma de actividades. Cada viernes, el líder muestra el avance en la reunión de 1 hora y registra las horas en la hoja de G8.

## G1 · Datos y SIG — `data/`
| Semanas | Qué hacer | Entregable |
|---|---|---|
| S1–S2 | Instalar Python, QGIS y rasterio. Conseguir el límite oficial de la parroquia 11 de Noviembre (INEC o IGM). Correr `data/soilgrids/descargar_soilgrids.py --limite ...` | Datos recortados |
| S3–S5 | Revisar calidad: celdas vacías, valores fuera de rango, textura que sume ~100 %. Documentar cada columna | Dataset v0 + diccionario |
| S6–S8 | Pedir al INIAP los rangos de P y K para la Sierra, ajustar los SUPUESTOS de `generar_npk.py` y generar el dataset final. Preparar solicitudes con `preparar_solicitudes.py` | Dataset final y solicitudes |
| S9–S12 | Cargar las celdas con `cargar_celdas.py` en la base de la nube y en la del fog. Mapas base en QGIS | Datos cargados en ambas bases |
| S13–S15 | Verificar que las tres arquitecturas devuelven las mismas zonas con la misma solicitud | Reporte de equivalencia |
| S16–S19 | Mapas finales de zonas, ficha del dataset (para Zenodo), informe | Figuras e informe |

## G2 · Algoritmos — `service/`
| Semanas | Qué hacer | Entregable |
|---|---|---|
| S1–S2 | Leer `clustering.py`, correr `pytest`. Leer Bradley, Bennett y Demiriz (2000) sobre k-means con restricciones de tamaño | Resumen del método |
| S3–S5 | Comparar `kmeans`, `kmeans_tamano` y `milp` en tamaños pequeños: tiempo, cumplimiento de tamaños, varianza | Tabla comparativa |
| S6–S8 | Agregar pruebas (casos límite, datos faltantes). Medir el tamaño máximo razonable de cada método | Pruebas y límites |
| S9–S12 | Publicar la imagen Docker v1.0 y apoyar los despliegues | Imagen etiquetada `v1.0` |
| S13–S15 | Congelar la versión: ningún cambio en `service/` durante los experimentos | Versión congelada |
| S16–S19 | Tabla de calidad de zonas para el artículo, documentación del código | Tabla e informe |

## G3 · Arquitectura en la nube — `deploy/cloud`
| Semanas | Qué hacer | Entregable |
|---|---|---|
| S1–S2 | Cuenta de AWS con alerta de presupuesto de 50 USD. Instancia de prueba | Cuenta lista |
| S3–S5 | Elegir el tipo de instancia con CPU y memoria comparables al servidor HP (ver `deploy/cloud/README.md`) | Propuesta de instancia |
| S6–S8 | Grupo de seguridad, Docker en la EC2, `docker compose --profile broker up` con datos de prueba | Nube respondiendo |
| S9–S12 | Monitoreo con G6; prueba de humo con el simulador de nodos | Paneles de la nube |
| S13–S15 | Ejecutar los escenarios de la nube con G6 | Datos de la nube |
| S16–S19 | Reporte de costos (factura de AWS), apagar y eliminar recursos | Reporte de costos |

## G4 · Arquitectura fog — `deploy/fog`
| Semanas | Qué hacer | Entregable |
|---|---|---|
| S1–S2 | Ubuntu Server 24.04, Docker y SSH con llaves en el servidor HP | Servidor listo |
| S3–S5 | Crear usuarios de Mosquitto, levantar `deploy/fog` con datos de prueba | Fog respondiendo |
| S6–S8 | Firewall (ufw), UPS, respaldos de la base | Servidor endurecido |
| S9–S12 | Con G5, levantar `deploy/hybrid` (fog + sincronizador) | Híbrida en el fog |
| S13–S15 | Ejecutar los escenarios del fog y de la híbrida con G6 | Datos del fog |
| S16–S19 | Reporte de uso de recursos, respaldo de configuraciones | Informe |

## G5 · Edge e IoT — `edge/`
| Semanas | Qué hacer | Entregable |
|---|---|---|
| S1–S2 | Inventario de placas (modelo y 915 MHz). Cargar `gateway_lora_mqtt.ino` en una placa y `nodo_sensor.ino` en otra; primer mensaje | Envío LoRa funcionando |
| S3–S5 | Conectar los sensores (ver `edge/README.md`), calibrar el sensor de humedad | Nodos en protoboard |
| S6–S8 | Probar store-and-forward: apagar el gateway 10 minutos y verificar que no se pierde nada | Prueba documentada |
| S9–S12 | Conectar los nodos al broker del fog y de la nube. Simulador con 20 nodos | Edge integrado |
| S13–S15 | Inyección de fallos (`experiments/fallos/`) y dos visitas de campo | Datos de resiliencia y de campo |
| S16–S19 | Ordenar datos de campo, inventario de nodos, informe | Informe |

## G6 · Pruebas y observabilidad — `experiments/`, `monitoring/`
| Semanas | Qué hacer | Entregable |
|---|---|---|
| S1–S2 | Instalar k6, Prometheus y Grafana. Probar `k6/carga_zonas.js` contra el servicio local | Primera prueba |
| S3–S5 | Revisar `generar_escenarios.py` con G7; panel de Grafana con latencia, CPU y memoria | Panel base |
| S6–S8 | Exportar métricas de Prometheus a CSV; automatizar la recolección | Exportación |
| S9–S12 | Monitoreo levantado en las tres arquitecturas | Paneles completos |
| S13–S15 | Prueba piloto (S13), `ejecutar_rendimiento.py` y `medir_resiliencia.py` | `resultados/*.csv` |
| S16–S19 | Repetir corridas fallidas, archivar datos crudos | Archivo de experimentos |

## G7 · Estadística y figuras — `analysis/`
| Semanas | Qué hacer | Entregable |
|---|---|---|
| S1–S2 | Correr `analisis.py --simular` y entender cada prueba | Informe de prácticas |
| S3–S5 | Con el autor: prueba estadística por hipótesis, nivel de significancia 0,05 | Plan de análisis |
| S6–S8 | Calcular si 30 repeticiones bastan (tamaño de efecto de la prueba piloto) | Justificación |
| S9–S12 | Análisis preliminares con los primeros datos reales | Reportes preliminares |
| S13–S15 | Analizar por lotes; marcar corridas dudosas para repetir | Avance del análisis |
| S16–S19 | Análisis final, tablas y figuras del artículo | Resultados y figuras |

## G8 · Literatura y documentación — `docs/`
| Semanas | Qué hacer | Entregable |
|---|---|---|
| S1–S2 | Biblioteca compartida en Zotero; búsqueda en Scopus, IEEE Xplore y WoS | Biblioteca |
| S3–S5 | Matriz de literatura (25 referencias), hoja de horas, plantillas de reporte | Matriz y hoja de horas |
| S6–S8 | Matriz completa (40–50), revisión de los README de cada carpeta, borradores de diagramas C4 | Matriz completa |
| S9–S12 | ADR de las decisiones nuevas (`docs/adr/`), manual técnico de despliegue | Manual técnico |
| S13–S15 | Probar que otra persona puede reproducir cada arquitectura con el manual. Bitácora de experimentos | Bitácora |
| S16–S19 | Revisión de referencias del manuscrito, certificados, informe integrado | Informe final |
