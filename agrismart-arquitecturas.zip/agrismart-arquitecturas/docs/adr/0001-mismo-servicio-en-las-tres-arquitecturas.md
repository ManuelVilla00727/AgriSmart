# ADR 0001: Mismo servicio, mismos datos y mismos límites de recursos en las tres arquitecturas

- **Estado:** aceptada
- **Fecha:** 2026-11-06

## Contexto
El artículo compara dónde se ubica el cómputo (nube, fog, híbrida). Si además cambiaran el código, los datos o los recursos asignados, no se podría atribuir una diferencia de rendimiento a la ubicación.

## Decisión
Una sola imagen Docker del servicio (`service/`), configurada solo con variables de entorno; las mismas solicitudes JSON con semilla fija; y los mismos límites de CPU y memoria para el contenedor del servicio (`API_CPUS`, `API_MEMORIA`, `API_WORKERS`).

## Alternativas consideradas
| Alternativa | A favor | En contra |
|---|---|---|
| Implementaciones distintas por arquitectura | Cada una optimizada | Confunde el efecto de la ubicación con el del código |
| Sin límites de recursos | Aprovecha todo el hardware | Gana quien tenga más núcleos, no la mejor ubicación |

## Consecuencias
La comparación es justa y reproducible. Se pierde algo de rendimiento máximo en la máquina más potente; se declara en el artículo. Se agrega un experimento de equivalencia como control.
