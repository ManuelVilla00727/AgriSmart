# ADR 0002: Store-and-forward en el edge y outbox con idempotencia entre fog y nube

- **Estado:** aceptada
- **Fecha:** 2026-11-06

## Contexto
La conectividad en la parroquia 11 de Noviembre es intermitente. Una lectura perdida no se puede volver a medir.

## Decisión
- Los nodos guardan cada lectura en flash y solo la borran cuando el gateway confirma (ACK), que a su vez solo confirma si publicó en MQTT.
- El fog marca cada lectura como pendiente de sincronizar (patrón outbox); el sincronizador la envía a la nube y solo la marca como sincronizada tras la confirmación.
- La API ignora lecturas repetidas por la clave `(nodo_id, secuencia)`, de modo que reenviar es seguro.
- Todos los reintentos usan backoff exponencial con jitter.

## Alternativas consideradas
| Alternativa | A favor | En contra |
|---|---|---|
| Envío directo sin confirmación | Simple | Pierde datos en cada corte |
| Transacciones distribuidas (2PC) entre fog y nube | Consistencia fuerte | No tolera la desconexión, que es justamente el caso normal |
| Replicación nativa de PostgreSQL | Sin código propio | Más compleja de operar; menos control para medir la recuperación |

## Consecuencias
Consistencia eventual entre fog y nube. Hay que vigilar el tamaño de la cola (`agrismart_sync_pendientes`) y el límite de 1000 lecturas por nodo. Si un nodo se reinicia, sus lecturas pendientes pierden la hora original.
