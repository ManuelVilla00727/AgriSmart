# ADR NNNN: Título corto de la decisión

- **Estado:** propuesta | aceptada | reemplazada por ADR NNNN
- **Fecha:** AAAA-MM-DD
- **Autores:**

## Contexto
Qué problema o fuerza obliga a decidir. Datos concretos (medidas, restricciones, plazos).

## Decisión
Qué se decidió, en una o dos frases.

## Alternativas consideradas
| Alternativa | A favor | En contra |
|---|---|---|

## Consecuencias
Qué gana y qué pierde el sistema. Qué hay que vigilar.
