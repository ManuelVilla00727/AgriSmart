# ADR 0003: k-means con restricciones de tamaño como método principal

- **Estado:** aceptada
- **Fecha:** 2026-11-06

## Contexto
Las zonas de manejo deben tener tamaños parecidos (por ejemplo, para repartir visitas técnicas y muestreos). El MILP exacto (p-mediana capacitada) solo resuelve en tiempo razonable hasta unos cientos de celdas.

## Decisión
Usar k-means con restricciones de tamaño (asignación exacta en cada iteración con el algoritmo húngaro, Bradley et al., 2000) como método principal hasta 3000 celdas; k-means simple como línea base; MILP solo como referencia de calidad en tamaños pequeños (hasta 400 celdas).

## Consecuencias
Tiempos de cálculo que crecen con el tamaño del problema, lo que permite observar la saturación de cada arquitectura. La solución es un óptimo local, no global; la comparación con el MILP en tamaños pequeños mide esa diferencia.
