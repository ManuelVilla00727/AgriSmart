"""Sincronizador fog -> nube (solo arquitectura híbrida).

Patrón outbox: el fog guarda todo localmente con sincronizado = false. Este proceso envía
lotes a la API de la nube y, solo si la nube confirma, los marca como sincronizados.
Si internet se cae, las lecturas se acumulan en el fog y se envían al volver la conexión.
Como /v1/lecturas es idempotente, reenviar un lote no duplica datos.
"""
from __future__ import annotations

import logging
import os
import random
import time

import httpx
import psycopg
from prometheus_client import Counter, Gauge, start_http_server

BD = os.environ["DATABASE_URL"]
NUBE = os.environ["CLOUD_API_URL"]  # ej. https://ec2-xx.compute.amazonaws.com
TOKEN = os.getenv("CLOUD_API_TOKEN")  # opcional, si se protege la API de la nube
LOTE = int(os.getenv("TAMANO_LOTE", "500"))
PAUSA = float(os.getenv("PAUSA_S", "5"))

logging.basicConfig(level=logging.INFO, format="%(asctime)s sync %(levelname)s %(message)s")
log = logging.getLogger()

PENDIENTES = Gauge("agrismart_sync_pendientes", "Lecturas del fog aún no enviadas a la nube")
ENVIADAS = Counter("agrismart_sync_enviadas_total", "Lecturas confirmadas por la nube")
FALLOS = Counter("agrismart_sync_fallos_total", "Intentos de sincronización fallidos")
ULTIMO_OK = Gauge("agrismart_sync_ultimo_ok_timestamp", "Hora (epoch) de la última sincronización exitosa")

COLUMNAS = ("nodo_id", "secuencia", "medido_en", "humedad_suelo", "temperatura_suelo",
            "temperatura_aire", "humedad_aire", "bateria_v", "rssi")


def ciclo(con: psycopg.Connection, cliente: httpx.Client) -> int:
    with con.cursor() as cur:
        cur.execute("SELECT count(*) FROM lecturas WHERE NOT sincronizado")
        PENDIENTES.set(cur.fetchone()[0])
        cur.execute(f"SELECT {', '.join(COLUMNAS)} FROM lecturas WHERE NOT sincronizado "
                    "ORDER BY medido_en LIMIT %s", (LOTE,))
        filas = cur.fetchall()
    if not filas:
        return 0
    lecturas = []
    for f in filas:
        d = dict(zip(COLUMNAS, f))
        d["medido_en"] = d["medido_en"].isoformat()
        lecturas.append(d)
    cabeceras = {"Authorization": f"Bearer {TOKEN}"} if TOKEN else {}
    r = cliente.post(f"{NUBE}/v1/lecturas", json={"origen": "sincronizador", "lecturas": lecturas},
                     headers=cabeceras, timeout=20)
    r.raise_for_status()
    with con.transaction(), con.cursor() as cur:
        cur.executemany("UPDATE lecturas SET sincronizado = true WHERE nodo_id = %s AND secuencia = %s",
                        [(l["nodo_id"], l["secuencia"]) for l in lecturas])
    ENVIADAS.inc(len(lecturas))
    ULTIMO_OK.set(time.time())
    log.info("Sincronizadas %d lecturas (respuesta nube: %s)", len(lecturas), r.json())
    return len(lecturas)


def main():
    start_http_server(9101)  # métricas para Prometheus
    intento = 0
    with httpx.Client() as cliente:
        while True:
            try:
                with psycopg.connect(BD, autocommit=True) as con:
                    while True:
                        enviadas = ciclo(con, cliente)
                        intento = 0
                        if enviadas < LOTE:
                            time.sleep(PAUSA)
            except (httpx.HTTPError, psycopg.OperationalError) as e:
                FALLOS.inc()
                intento += 1
                espera = min(120, 2 ** intento) * random.uniform(0.5, 1.0)
                log.warning("Sin conexión con la nube o la BD (%s). Reintento en %.1f s", e, espera)
                time.sleep(espera)


if __name__ == "__main__":
    main()
