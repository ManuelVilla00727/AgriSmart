#!/usr/bin/env bash
# Inyección de fallos de red (grupos G5 y G6). Requiere Linux y permisos de sudo.
# Se aplica en la máquina que hace de "borde" del enlace que se quiere cortar:
#   - cloud:   en el servidor que conecta el gateway con internet (corta el acceso a la EC2)
#   - híbrida: en el servidor HP (corta su salida a la nube; el fog debe seguir funcionando)
#
# Uso:
#   sudo ./red.sh estado   IFACE
#   sudo ./red.sh degradar IFACE 300ms 10%     # latencia y pérdida de paquetes
#   sudo ./red.sh cortar   IFACE               # 100 % de pérdida
#   sudo ./red.sh restaurar IFACE
#   sudo ./red.sh corte_temporal IFACE 120     # corta 120 s y restaura (registra horas en fallos.log)
#
# Nunca lo ejecutes sobre la interfaz por la que entras por SSH sin un plan para volver:
# usa corte_temporal, que se restaura solo.
set -euo pipefail
accion=${1:?accion}; iface=${2:?interfaz, por ejemplo eth0}
registrar() { echo "$(date -u +%Y-%m-%dT%H:%M:%SZ),$accion,$iface,$*" >> "$(dirname "$0")/fallos.log"; }
case "$accion" in
  estado)    tc qdisc show dev "$iface" ;;
  degradar)  tc qdisc replace dev "$iface" root netem delay "${3:-300ms}" loss "${4:-10%}"; registrar "${3:-300ms}" "${4:-10%}" ;;
  cortar)    tc qdisc replace dev "$iface" root netem loss 100%; registrar inicio ;;
  restaurar) tc qdisc del dev "$iface" root 2>/dev/null || true; registrar fin ;;
  corte_temporal)
    seg=${3:-120}
    tc qdisc replace dev "$iface" root netem loss 100%; registrar inicio "$seg"
    sleep "$seg"
    tc qdisc del dev "$iface" root 2>/dev/null || true; registrar fin "$seg" ;;
  *) echo "Acción no reconocida: $accion"; exit 1 ;;
esac
