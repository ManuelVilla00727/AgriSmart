#!/usr/bin/env bash
# Alternativa sin tocar la red del servidor: desconecta un contenedor de su red de Docker.
# Útil para simular que el sincronizador (híbrida) o la ingesta pierden la conexión.
# Uso: ./cortar_contenedor.sh NOMBRE_CONTENEDOR SEGUNDOS
#   docker ps   (para ver el nombre, por ejemplo hybrid-sync-1)
set -euo pipefail
c=${1:?contenedor}; seg=${2:-120}
red=$(docker inspect -f '{{range $k, $v := .NetworkSettings.Networks}}{{$k}}{{end}}' "$c")
echo "$(date -u +%Y-%m-%dT%H:%M:%SZ),inicio,$c,$red,$seg" >> "$(dirname "$0")/fallos.log"
docker network disconnect "$red" "$c"
sleep "$seg"
docker network connect "$red" "$c"
echo "$(date -u +%Y-%m-%dT%H:%M:%SZ),fin,$c,$red,$seg" >> "$(dirname "$0")/fallos.log"
