"""Experimento de resiliencia ante cortes de red (grupos G5 y G6).

Para una corrida:
  1. Arranca el simulador de nodos (con store-and-forward) durante --duracion segundos.
  2. A los --inicio-corte segundos ejecuta el comando de corte (por ejemplo, red.sh corte_temporal).
  3. Consulta cada 5 s /v1/lecturas/resumen en la API DONDE TERMINAN LOS DATOS:
       cloud   -> API de la nube
       fog     -> API del fog
       hibrida -> API de la nube (mide si la sincronización recupera todo)
  4. Calcula lecturas perdidas y el tiempo de recuperación (desde que vuelve la red hasta
     que la API tiene todas las lecturas generadas).

Uso (ejemplo híbrida, corte de 60 s en la salida del servidor HP):
  python medir_resiliencia.py --arquitectura hibrida --api http://EC2:8000 --broker 192.168.1.50 \
     --usuario agrismart --clave XXX --corte-s 60 \
     --comando-corte "ssh admin@192.168.1.50 sudo /opt/agrismart/experiments/fallos/red.sh corte_temporal eth0 60"
"""
from __future__ import annotations

import argparse
import csv
import shlex
import subprocess
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

import httpx

CAMPOS = ["id", "arquitectura", "corte_s", "rep", "inicio_utc", "nodos", "generadas", "recibidas", "perdidas",
          "tasa_perdida", "recuperacion_s", "max_pendiente"]


def total(api: str, prefijo: str) -> int:
    r = httpx.get(f"{api}/v1/lecturas/resumen", timeout=10).json()
    return sum(v["recibidas"] for n, v in r["nodos"].items() if n.startswith(prefijo))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--arquitectura", required=True, choices=["cloud", "fog", "hibrida"])
    ap.add_argument("--api", required=True)
    ap.add_argument("--broker", required=True)
    ap.add_argument("--usuario")
    ap.add_argument("--clave")
    ap.add_argument("--nodos", type=int, default=20)
    ap.add_argument("--intervalo", type=float, default=5)
    ap.add_argument("--duracion", type=int, default=600)
    ap.add_argument("--inicio-corte", type=int, default=120)
    ap.add_argument("--corte-s", type=int, required=True)
    ap.add_argument("--comando-corte", required=True, help="comando que corta la red durante corte-s segundos")
    ap.add_argument("--id", default="manual")
    ap.add_argument("--rep", default="1")
    ap.add_argument("--espera-final", type=int, default=600, help="tiempo máximo de espera de recuperación")
    a = ap.parse_args()

    corrida = f"{a.id}-{int(time.time())}"
    prefijo = f"{a.id}_{int(time.time())}_"  # nodos nuevos en cada corrida: no se mezclan con otras
    inicio = datetime.now(timezone.utc).isoformat(timespec="seconds")
    sim = subprocess.Popen([sys.executable, "../edge/simulador/simulador_nodos.py", "--broker", a.broker,
                            "--nodos", str(a.nodos), "--intervalo", str(a.intervalo), "--duracion", str(a.duracion),
                            "--prefijo", prefijo, "--cola", f"cola_{corrida}.sqlite", "--salida", "resultados/simulador.csv"]
                           + (["--usuario", a.usuario, "--clave", a.clave] if a.usuario else []),
                           stdout=subprocess.PIPE, text=True)
    fin_corte = {}
    t0 = time.time()
    estado = {"recuperacion": None, "max_pendiente": 0}

    def cortar():
        time.sleep(a.inicio_corte)
        subprocess.run(shlex.split(a.comando_corte), check=False)
        fin_corte["t"] = time.time()

    def vigilar():
        """Cada 2 s compara lo esperado (nodos x intervalos transcurridos) con lo recibido.

        Tiempo de recuperación = desde que termina el corte hasta que lo pendiente vuelve a ser
        como máximo una ronda de lecturas (los nodos ya se pusieron al día).
        """
        while sim.poll() is None:
            transcurrido = min(time.time() - t0, a.duracion)
            esperado = a.nodos * int(transcurrido // a.intervalo)
            try:
                pendiente = esperado - total(a.api, prefijo)
            except httpx.HTTPError:
                pendiente = None
            if pendiente is not None:
                estado["max_pendiente"] = max(estado["max_pendiente"], pendiente)
                if "t" in fin_corte and estado["recuperacion"] is None and pendiente <= a.nodos:
                    estado["recuperacion"] = round(time.time() - fin_corte["t"], 1)
            time.sleep(2)

    threading.Thread(target=cortar, daemon=True).start()
    threading.Thread(target=vigilar, daemon=True).start()
    salida_sim = sim.communicate()[0]
    print(salida_sim)
    generadas = int(salida_sim.split("Generadas:")[1].split("|")[0])
    t_fin_sim = time.time()

    recibidas = 0
    while time.time() - t_fin_sim < a.espera_final:
        try:
            recibidas = total(a.api, prefijo)
        except httpx.HTTPError:
            pass
        if recibidas >= generadas:
            break
        time.sleep(5)
    recuperacion = estado["recuperacion"]
    perdidas = max(0, generadas - recibidas)
    fila = {"id": a.id, "arquitectura": a.arquitectura, "corte_s": a.corte_s, "rep": a.rep, "inicio_utc": inicio,
            "nodos": a.nodos, "generadas": generadas, "recibidas": recibidas, "perdidas": perdidas,
            "tasa_perdida": round(perdidas / generadas, 4) if generadas else None,
            "recuperacion_s": recuperacion, "max_pendiente": estado["max_pendiente"]}
    ruta = Path("resultados/resiliencia.csv")
    ruta.parent.mkdir(exist_ok=True)
    nuevo = not ruta.exists()
    with open(ruta, "a", newline="") as f:
        w = csv.DictWriter(f, fieldnames=CAMPOS)
        if nuevo:
            w.writeheader()
        w.writerow(fila)
    print(fila)


if __name__ == "__main__":
    main()
