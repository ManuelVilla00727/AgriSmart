// Prueba de carga del servicio de zonas (grupo G6). Misma prueba en las tres arquitecturas.
//
// Uso:
//   k6 run -e API=http://IP:8000 -e N=1000 -e VUS=8 -e DURACION=2m \
//          -e ARQ=fog -e RED=estable -e REP=1 --summary-export=../resultados/fog_n1000_v8_r1.json carga_zonas.js
//
// Variables: API (URL del servicio), N (tamaño: 300, 1000, 2500), VUS (usuarios concurrentes),
// DURACION, ARQ (cloud|fog|hibrida), RED (estable|degradada|corte), REP (número de repetición).
import http from 'k6/http';
import { check } from 'k6';
import { Trend, Rate } from 'k6/metrics';

const N = __ENV.N || '1000';
const cuerpo = open(`../solicitudes/solicitud_n${N}.json`);
const tiempoAlgoritmo = new Trend('tiempo_algoritmo_ms', true);
const cumplimiento = new Rate('cumplimiento_tamanos_ok');

export const options = {
  scenarios: {
    carga: {
      executor: 'constant-vus',
      vus: Number(__ENV.VUS || 4),
      duration: __ENV.DURACION || '2m',
    },
  },
  tags: { arquitectura: __ENV.ARQ || 'sin_definir', n: N, red: __ENV.RED || 'estable', rep: __ENV.REP || '1' },
  summaryTrendStats: ['avg', 'min', 'med', 'p(90)', 'p(95)', 'p(99)', 'max'],
};

export default function () {
  const r = http.post(`${__ENV.API}/v1/zonas`, cuerpo, {
    headers: { 'Content-Type': 'application/json' },
    timeout: '180s',
  });
  const ok = check(r, { 'estado 200': (x) => x.status === 200 });
  if (ok) {
    const j = r.json();
    tiempoAlgoritmo.add(j.tiempo_algoritmo_ms);
    cumplimiento.add(j.metricas.cumplimiento_tamanos === 1);
  }
}
