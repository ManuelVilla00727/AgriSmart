"""Genera la matriz de escenarios en orden aleatorio (grupo G6, revisa G7).

Experimento 1 · Rendimiento: arquitectura x tamaño del problema x usuarios concurrentes x 30 repeticiones.
Experimento 2 · Resiliencia: arquitectura x duración del corte de red x 10 repeticiones.

El orden aleatorio evita sesgos (por ejemplo, que todas las pruebas de una arquitectura se corran
de noche, cuando la red está más libre). La semilla fija hace que la matriz sea reproducible.

Uso: python generar_escenarios.py   ->  escenarios_rendimiento.csv y escenarios_resiliencia.csv
"""
import csv
import itertools
import random

SEMILLA = 2026
ARQUITECTURAS = ["cloud", "fog", "hibrida"]
TAMANOS = [300, 1000, 2500]          # celdas por solicitud (se fijan en la prueba piloto, S14)
USUARIOS = [1, 8, 32]                # usuarios concurrentes de k6
REP_RENDIMIENTO = 30
DURACION_PRUEBA = "1m"
CORTES_S = [60, 300]                 # duración del corte de red, en segundos
REP_RESILIENCIA = 10


def escribir(nombre, filas, campos):
    with open(nombre, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=campos)
        w.writeheader()
        w.writerows(filas)
    print(f"{nombre}: {len(filas)} corridas")


def main():
    rnd = random.Random(SEMILLA)
    rend = [{"id": f"R{i:04d}", "arquitectura": a, "n": n, "vus": v, "rep": r, "duracion": DURACION_PRUEBA}
            for i, (a, n, v, r) in enumerate(itertools.product(ARQUITECTURAS, TAMANOS, USUARIOS,
                                                                range(1, REP_RENDIMIENTO + 1)), 1)]
    rnd.shuffle(rend)
    for orden, fila in enumerate(rend, 1):
        fila["orden"] = orden
    escribir("escenarios_rendimiento.csv", rend, ["orden", "id", "arquitectura", "n", "vus", "rep", "duracion"])

    resi = [{"id": f"F{i:03d}", "arquitectura": a, "corte_s": c, "rep": r}
            for i, (a, c, r) in enumerate(itertools.product(ARQUITECTURAS, CORTES_S, range(1, REP_RESILIENCIA + 1)), 1)]
    rnd.shuffle(resi)
    for orden, fila in enumerate(resi, 1):
        fila["orden"] = orden
    escribir("escenarios_resiliencia.csv", resi, ["orden", "id", "arquitectura", "corte_s", "rep"])
    minutos = len(rend) * int(DURACION_PRUEBA.rstrip("m"))
    print(f"Tiempo estimado de rendimiento: {minutos} min (~{minutos / 60:.1f} h, sin contar pausas)")


if __name__ == "__main__":
    main()
