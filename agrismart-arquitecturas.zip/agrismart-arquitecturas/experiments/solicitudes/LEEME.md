Aquí van las solicitudes que genera `data/preparar_solicitudes.py` (solicitud_n300.json, solicitud_n1000.json, ...).
`ejemplo_sintetico_n300.json` es un ejemplo con datos SINTÉTICOS para practicar; no se usa en el artículo.
