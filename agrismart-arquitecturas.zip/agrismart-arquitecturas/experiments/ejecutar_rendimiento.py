"""Ejecuta el experimento de rendimiento para UNA arquitectura (grupo G6 con G3/G4/G5).

Recorre escenarios_rendimiento.csv en el orden aleatorio, corre k6 por cada fila de esa
arquitectura y agrega una fila a resultados/rendimiento.csv. Si se interrumpe, al volver a
ejecutarlo salta las corridas ya hechas.

Uso (desde la máquina generadora de carga, NUNCA desde el mismo servidor que se mide):
  python ejecutar_rendimiento.py --arquitectura fog --api http://192.168.1.50:8000
"""
from __future__ import annotations

import argparse
import csv
import json
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

import httpx

CAMPOS = ["orden", "id", "arquitectura", "n", "vus", "rep", "inicio_utc", "solicitudes", "throughput_rps",
          "tasa_error", "lat_p50_ms", "lat_p95_ms", "lat_p99_ms", "algoritmo_med_ms", "cumplimiento"]


def hechas(ruta: Path) -> set[str]:
    if not ruta.exists():
        return set()
    with open(ruta) as f:
        return {r["id"] for r in csv.DictReader(f)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arquitectura", required=True, choices=["cloud", "fog", "hibrida"])
    ap.add_argument("--api", required=True)
    ap.add_argument("--pausa", type=int, default=20, help="segundos de enfriamiento entre corridas")
    a = ap.parse_args()

    salida = Path("resultados/rendimiento.csv")
    crudos = Path("resultados/k6")
    crudos.mkdir(parents=True, exist_ok=True)
    listas = hechas(salida)
    salud = httpx.get(f"{a.api}/health", timeout=10).json()
    if salud.get("arquitectura") != a.arquitectura:
        raise SystemExit(f"La API responde como '{salud.get('arquitectura')}', no como '{a.arquitectura}'. Revisa la URL.")

    with open("escenarios_rendimiento.csv") as f:
        filas = [r for r in csv.DictReader(f) if r["arquitectura"] == a.arquitectura and r["id"] not in listas]
    print(f"{len(filas)} corridas pendientes para {a.arquitectura}")
    nuevo = not salida.exists()
    for r in filas:
        resumen = crudos / f"{r['id']}.json"
        inicio = datetime.now(timezone.utc).isoformat(timespec="seconds")
        cmd = ["k6", "run", "--quiet", "-e", f"API={a.api}", "-e", f"N={r['n']}", "-e", f"VUS={r['vus']}",
               "-e", f"DURACION={r['duracion']}", "-e", f"ARQ={a.arquitectura}", "-e", "RED=estable",
               "-e", f"REP={r['rep']}", f"--summary-export={resumen}", "k6/carga_zonas.js"]
        print(f"[{r['orden']}] {r['id']} n={r['n']} vus={r['vus']} rep={r['rep']}")
        subprocess.run(cmd, check=False)
        m = json.loads(resumen.read_text())["metrics"]
        dur = m["http_req_duration"]
        fila = {**{k: r[k] for k in ("orden", "id", "arquitectura", "n", "vus", "rep")}, "inicio_utc": inicio,
                "solicitudes": m["http_reqs"]["count"], "throughput_rps": round(m["http_reqs"]["rate"], 4),
                "tasa_error": round(m.get("http_req_failed", {}).get("value", 0), 4),
                "lat_p50_ms": round(dur["med"], 2), "lat_p95_ms": round(dur["p(95)"], 2),
                "lat_p99_ms": round(dur["p(99)"], 2),
                "algoritmo_med_ms": round(m.get("tiempo_algoritmo_ms", {}).get("med", 0), 2),
                "cumplimiento": round(m.get("cumplimiento_tamanos_ok", {}).get("value", 0), 4)}
        with open(salida, "a", newline="") as f:
            w = csv.DictWriter(f, fieldnames=CAMPOS)
            if nuevo:
                w.writeheader()
                nuevo = False
            w.writerow(fila)
        time.sleep(a.pausa)


if __name__ == "__main__":
    main()
