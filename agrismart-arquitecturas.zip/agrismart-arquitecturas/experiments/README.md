# Experimentos (grupo G6, con G3, G4, G5 y G7)

La guía completa está en [`../docs/04-experimentos.md`](../docs/04-experimentos.md).

| Archivo | Para qué |
|---|---|
| `generar_escenarios.py` | Matriz de corridas en orden aleatorio (ya generada: `escenarios_*.csv`) |
| `k6/carga_zonas.js` | Prueba de carga de `/v1/zonas` (instala k6: https://k6.io) |
| `ejecutar_rendimiento.py` | Corre todas las pruebas de carga de una arquitectura y guarda `resultados/rendimiento.csv` |
| `medir_resiliencia.py` | Corre el simulador, corta la red y mide pérdida y recuperación |
| `fallos/red.sh` | Degrada o corta la red de un servidor Linux (tc netem) |
| `fallos/cortar_contenedor.sh` | Desconecta un contenedor de su red por unos segundos |
| `solicitudes/` | Solicitudes JSON que genera `data/preparar_solicitudes.py` |
