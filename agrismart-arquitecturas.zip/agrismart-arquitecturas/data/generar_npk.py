"""Agrega fósforo (P) y potasio (K) sintéticos a la tabla de celdas (grupo G1).

SoilGrids no tiene P ni K. Para el artículo se generan valores sintéticos con:
  - un rango y una media de referencia (SUPUESTOS: reemplázalos por los rangos del INIAP
    para suelos de la Sierra y cita la fuente en el artículo);
  - correlación con el carbono orgánico (más materia orgánica, algo más de P y K);
  - continuidad espacial (celdas vecinas se parecen), con ruido suavizado.

Uso:
  python generar_npk.py --entrada soilgrids/salida/celdas_soilgrids.csv --salida celdas_completas.csv
"""
from __future__ import annotations

import argparse

import numpy as np
import pandas as pd
from scipy.ndimage import gaussian_filter

# ---------------- SUPUESTOS (calibrar con el INIAP) ----------------
P_MEDIA_MG_KG, P_DE, P_MIN, P_MAX = 18.0, 7.0, 3.0, 60.0       # fósforo disponible, mg/kg
K_MEDIA_CMOL, K_DE, K_MIN, K_MAX = 0.45, 0.18, 0.08, 1.5       # potasio intercambiable, cmol/kg
CORRELACION_SOC = 0.4      # peso del carbono orgánico en P y K (0 = independiente)
SUAVIZADO_CELDAS = 2.0     # cuántas celdas abarca la continuidad espacial
SEMILLA = 2026
# -------------------------------------------------------------------


def campo_espacial(df: pd.DataFrame, rng: np.random.Generator) -> np.ndarray:
    """Ruido con continuidad espacial sobre la grilla de SoilGrids (ids r{fila}_c{col})."""
    f = df.id.str.extract(r"r(\d+)_c(\d+)").astype(int)
    alto, ancho = f[0].max() + 1, f[1].max() + 1
    ruido = gaussian_filter(rng.normal(size=(alto, ancho)), SUAVIZADO_CELDAS)
    ruido = (ruido - ruido.mean()) / ruido.std()
    return ruido[f[0].values, f[1].values]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--entrada", required=True)
    ap.add_argument("--salida", required=True)
    a = ap.parse_args()
    rng = np.random.default_rng(SEMILLA)
    df = pd.read_csv(a.entrada)
    soc_z = (df.carbono_organico - df.carbono_organico.mean()) / df.carbono_organico.std()
    for col, media, de, lo, hi in (("fosforo", P_MEDIA_MG_KG, P_DE, P_MIN, P_MAX),
                                   ("potasio", K_MEDIA_CMOL, K_DE, K_MIN, K_MAX)):
        z = CORRELACION_SOC * soc_z + np.sqrt(1 - CORRELACION_SOC ** 2) * campo_espacial(df, rng)
        df[col] = np.round(np.clip(media + de * z, lo, hi), 3)
        print(f"{col}: media {df[col].mean():.2f}, mín {df[col].min():.2f}, máx {df[col].max():.2f}")
    df["fuente_pk"] = "sintetico"
    df.to_csv(a.salida, index=False)
    print(f"Guardado {a.salida} ({len(df)} celdas)")


if __name__ == "__main__":
    main()
