"""Carga la tabla de celdas en PostGIS (grupo G1, con G3 y G4).

Uso:
  python cargar_celdas.py --csv celdas_completas.csv --bd postgresql://agrismart:CLAVE@HOST:5432/agrismart
Se ejecuta una vez en cada base de datos (nube y fog), para que las tres arquitecturas tengan los mismos datos.
"""
from __future__ import annotations

import argparse

import pandas as pd
import psycopg

COLS = ["ph", "nitrogeno", "carbono_organico", "arcilla", "arena", "limo", "fosforo", "potasio"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True)
    ap.add_argument("--bd", required=True)
    a = ap.parse_args()
    df = pd.read_csv(a.csv)
    for c in COLS:
        if c not in df:
            df[c] = None
    filas = [(r.id, r.lon, r.lat, *[None if pd.isna(getattr(r, c)) else float(getattr(r, c)) for c in COLS])
             for r in df.itertuples()]
    with psycopg.connect(a.bd) as con, con.cursor() as cur:
        cur.executemany(
            f"""INSERT INTO celdas (id, geom, {', '.join(COLS)})
                VALUES (%s, ST_SetSRID(ST_MakePoint(%s, %s), 4326), {', '.join(['%s'] * len(COLS))})
                ON CONFLICT (id) DO UPDATE SET {', '.join(f'{c} = EXCLUDED.{c}' for c in COLS)}""", filas)
    print(f"Cargadas {len(filas)} celdas")


if __name__ == "__main__":
    main()
