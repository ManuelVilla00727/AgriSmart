# Datos (grupo G1)

Flujo completo:
```bash
pip install rasterio numpy pandas scipy geopandas psycopg[binary]

# 1. SoilGrids recortado con el límite oficial de la parroquia
python soilgrids/descargar_soilgrids.py --limite limites/parroquia_11_noviembre.geojson \
       --salida soilgrids/salida/celdas_soilgrids.csv

# 2. Fósforo y potasio sintéticos (ajusta antes los SUPUESTOS con los rangos del INIAP)
python generar_npk.py --entrada soilgrids/salida/celdas_soilgrids.csv --salida celdas_completas.csv

# 3. Cargar en las bases de la nube y del fog
python cargar_celdas.py --csv celdas_completas.csv --bd postgresql://agrismart:CLAVE@IP_FOG:5432/agrismart
python cargar_celdas.py --csv celdas_completas.csv --bd postgresql://agrismart:CLAVE@IP_EC2:5432/agrismart

# 4. Solicitudes de los experimentos
python preparar_solicitudes.py --celdas celdas_completas.csv --tamanos 300 1000 2500 --k 8
```
Para acceder a PostgreSQL de forma remota, publica temporalmente el puerto 5432 del contenedor `db` solo para la IP del laboratorio, o corre `cargar_celdas.py` dentro del servidor.

## Qué revisar en el dataset
- pH entre 3 y 10; arcilla + arena + limo cerca de 100 %.
- Celdas sin dato (agua, roca, zona urbana) se eliminan.
- Si la parroquia tiene menos de 2500 celdas, usa el cantón para los tamaños grandes o reduce los tamaños en `generar_escenarios.py` (decisión del autor, con ADR).

## Conversiones de SoilGrids (ya aplicadas en el script)
| Propiedad | Viene en | Se divide para | Queda en |
|---|---|---|---|
| phh2o | pH × 10 | 10 | pH |
| nitrogen | cg/kg | 100 | g/kg |
| soc | dg/kg | 10 | g/kg |
| clay, sand, silt | g/kg | 10 | % |

Cita: Poggio, L. et al. (2021). SoilGrids 2.0: producing soil information for the globe with quantified spatial uncertainty. *SOIL*, 7, 217–240.
