"""Prepara los archivos JSON de solicitud para los experimentos (grupos G1 y G6).

Toma la tabla de celdas y genera una solicitud /v1/zonas por cada tamaño de problema.
Las mismas solicitudes se usan en las tres arquitecturas: así la carga es idéntica.

Uso:
  python preparar_solicitudes.py --celdas celdas_completas.csv --tamanos 300 1000 2500 --k 8
  python preparar_solicitudes.py --sinteticas --tamanos 300 1000 2500   # sin datos reales, para practicar
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

VARIABLES = ["ph", "nitrogeno", "carbono_organico", "arcilla", "arena", "fosforo", "potasio"]


def sinteticas(n: int, semilla: int = 1) -> pd.DataFrame:
    rng = np.random.default_rng(semilla)
    lado = math.ceil(math.sqrt(n))
    filas = []
    for i in range(n):
        f, c = divmod(i, lado)
        filas.append({"id": f"r{f}_c{c}", "lat": -0.95 + f * 0.00225, "lon": -78.75 + c * 0.00225,
                      "ph": rng.normal(6.1, 0.5), "nitrogeno": rng.normal(2.2, 0.6),
                      "carbono_organico": rng.normal(28, 8), "arcilla": rng.normal(17, 5),
                      "arena": rng.normal(48, 9), "fosforo": rng.normal(18, 7), "potasio": rng.normal(0.45, 0.18)})
    return pd.DataFrame(filas)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--celdas", help="CSV con las celdas (salida de generar_npk.py)")
    ap.add_argument("--sinteticas", action="store_true")
    ap.add_argument("--tamanos", nargs="+", type=int, default=[300, 1000, 2500])
    ap.add_argument("--k", type=int, default=8, help="número de zonas")
    ap.add_argument("--tolerancia", type=float, default=0.15, help="holgura de tamaño (+/- 15 %)")
    ap.add_argument("--metodo", default="kmeans_tamano")
    ap.add_argument("--salida", default="../experiments/solicitudes")
    a = ap.parse_args()
    Path(a.salida).mkdir(parents=True, exist_ok=True)
    for n in a.tamanos:
        df = sinteticas(n) if a.sinteticas else pd.read_csv(a.celdas)
        if len(df) < n:
            raise SystemExit(f"Solo hay {len(df)} celdas; no alcanza para n={n}")
        df = df.sample(n=n, random_state=42) if len(df) > n else df
        media = n / a.k
        sol = {"celdas": df[["id", "lat", "lon"] + VARIABLES].round(4).to_dict(orient="records"),
               "k": a.k, "metodo": a.metodo,
               "tamano_min": int(math.floor(media * (1 - a.tolerancia))),
               "tamano_max": int(math.ceil(media * (1 + a.tolerancia))),
               "variables": VARIABLES, "peso_espacial": 0.5, "semilla": 42,
               "etiqueta_experimento": f"n{n}_k{a.k}"}
        ruta = Path(a.salida) / f"solicitud_n{n}.json"
        ruta.write_text(json.dumps(sol))
        print(f"{ruta}: {n} celdas, tamaños {sol['tamano_min']}–{sol['tamano_max']}")


if __name__ == "__main__":
    main()
