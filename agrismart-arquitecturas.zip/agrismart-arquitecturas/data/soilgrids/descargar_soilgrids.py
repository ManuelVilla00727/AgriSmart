"""Descarga SoilGrids 2.0 para un área y la convierte en la tabla de celdas (grupo G1).

Qué hace:
  1. Lee los mapas de SoilGrids (ISRIC) directamente del servidor, solo para el área pedida.
  2. Los reproyecta a WGS84 (EPSG:4326) con celdas de ~250 m.
  3. Convierte los valores a unidades convencionales (los mapas guardan enteros escalados).
  4. Promedia 0–5, 5–15 y 15–30 cm ponderando por espesor (5, 10 y 15 cm) -> capa 0–30 cm.
  5. Opcional: recorta con el límite oficial de la parroquia (GeoJSON o Shapefile del INEC/IGM).
  6. Guarda un CSV con las columnas que espera la API: id, lat, lon, ph, nitrogeno, ...

Requisitos: pip install rasterio numpy pandas  (y geopandas si usas --limite)

Uso:
  python descargar_soilgrids.py --bbox -78.75 -0.95 -78.55 -0.80 --salida salida/celdas_soilgrids.csv
  python descargar_soilgrids.py --limite limites/parroquia_11_noviembre.geojson --salida salida/celdas.csv

IMPORTANTE: el --bbox de ejemplo es aproximado. Usa el límite oficial de la parroquia.
Cita obligatoria: Poggio, L. et al. (2021). SoilGrids 2.0: producing soil information for the
globe with quantified spatial uncertainty. SOIL, 7, 217–240.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import rasterio
from rasterio.enums import Resampling
from rasterio.vrt import WarpedVRT
from rasterio.windows import from_bounds

URL = "/vsicurl/https://files.isric.org/soilgrids/latest/data/{p}/{p}_{d}_mean.vrt"
PROFUNDIDADES = {"0-5cm": 5, "5-15cm": 10, "15-30cm": 15}
# propiedad de SoilGrids -> (columna de la API, factor de conversión, unidad convencional)
PROPIEDADES = {
    "phh2o":    ("ph", 10, "pH"),
    "nitrogen": ("nitrogeno", 100, "g/kg"),
    "soc":      ("carbono_organico", 10, "g/kg"),
    "clay":     ("arcilla", 10, "%"),
    "sand":     ("arena", 10, "%"),
    "silt":     ("limo", 10, "%"),
}
RESOLUCION_GRADOS = 0.00225  # ~250 m en el ecuador


def leer_capa(prop: str, prof: str, bbox: tuple[float, float, float, float]) -> tuple[np.ndarray, rasterio.Affine]:
    oeste, sur, este, norte = bbox
    ancho = int(round((este - oeste) / RESOLUCION_GRADOS))
    alto = int(round((norte - sur) / RESOLUCION_GRADOS))
    transform = rasterio.transform.from_bounds(oeste, sur, este, norte, ancho, alto)
    with rasterio.Env(GDAL_DISABLE_READDIR_ON_OPEN="EMPTY_DIR", GDAL_HTTP_MAX_RETRY="5", GDAL_HTTP_RETRY_DELAY="2"):
        with rasterio.open(URL.format(p=prop, d=prof)) as src:
            with WarpedVRT(src, crs="EPSG:4326", transform=transform, width=ancho, height=alto,
                           resampling=Resampling.bilinear) as vrt:
                datos = vrt.read(1, window=from_bounds(oeste, sur, este, norte, transform)).astype(float)
                nodata = src.nodata
    if nodata is not None:
        datos[datos == nodata] = np.nan
    datos[datos <= 0] = np.nan  # 0 suele indicar ausencia de dato (agua, roca, zona urbana)
    return datos, transform


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--bbox", nargs=4, type=float, metavar=("OESTE", "SUR", "ESTE", "NORTE"),
                    default=[-78.75, -0.95, -78.55, -0.80], help="límites en grados (aproximado por defecto)")
    ap.add_argument("--limite", help="GeoJSON o Shapefile con el polígono de la parroquia")
    ap.add_argument("--salida", default="salida/celdas_soilgrids.csv")
    a = ap.parse_args()

    poligono = None
    bbox = tuple(a.bbox)
    if a.limite:
        import geopandas as gpd
        poligono = gpd.read_file(a.limite).to_crs("EPSG:4326")
        bbox = tuple(poligono.total_bounds)

    capas = {}
    transform = None
    for prop, (col, factor, unidad) in PROPIEDADES.items():
        suma, pesos = None, 0
        for prof, espesor in PROFUNDIDADES.items():
            print(f"Descargando {prop} {prof} ...")
            datos, transform = leer_capa(prop, prof, bbox)
            datos = datos / factor
            suma = datos * espesor if suma is None else suma + datos * espesor
            pesos += espesor
        capas[col] = suma / pesos
        print(f"  {col} ({unidad}) 0–30 cm: media {np.nanmean(capas[col]):.2f}")

    alto, ancho = next(iter(capas.values())).shape
    filas, cols = np.mgrid[0:alto, 0:ancho]
    lon, lat = rasterio.transform.xy(transform, filas.ravel(), cols.ravel(), offset="center")
    df = pd.DataFrame({"id": [f"r{f}_c{c}" for f, c in zip(filas.ravel(), cols.ravel())],
                       "lat": np.round(lat, 6), "lon": np.round(lon, 6)})
    for col, arr in capas.items():
        df[col] = np.round(arr.ravel(), 3)
    df = df.dropna()

    if poligono is not None:
        import geopandas as gpd
        puntos = gpd.GeoDataFrame(df, geometry=gpd.points_from_xy(df.lon, df.lat), crs="EPSG:4326")
        df = gpd.sjoin(puntos, poligono[["geometry"]], predicate="within").drop(columns=["geometry", "index_right"])

    # Control de calidad mínimo: rangos físicamente posibles
    assert df.ph.between(3, 10).all(), "pH fuera de rango: revisa la conversión"
    assert (df.arcilla + df.arena + df.limo).between(90, 110).all(), "La textura no suma ~100 %"

    Path(a.salida).parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(a.salida, index=False)
    print(f"Guardadas {len(df)} celdas en {a.salida}")


if __name__ == "__main__":
    main()
